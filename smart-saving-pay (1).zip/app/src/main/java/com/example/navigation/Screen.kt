package com.example.navigation

sealed class Screen(val route: String) {
  object Splash : Screen("splash")
  object Onboarding : Screen("onboarding")
  object SignUp : Screen("signup")
  object Login : Screen("login")
  object Otp : Screen("otp/{phone}") {
    fun createRoute(phone: String) = "otp/${java.net.URLEncoder.encode(phone, "UTF-8")}"
  }
  object Main : Screen("main?tab={tab}") {
    fun createRoute(tab: String = "home") = "main?tab=$tab"
  }
  object SendMoney : Screen("send_money?payee={payee}&upi={upi}&amount={amount}") {
    fun createRoute(payee: String = "", upi: String = "", amount: String = ""): String {
      val p = java.net.URLEncoder.encode(payee, "UTF-8")
      val u = java.net.URLEncoder.encode(upi, "UTF-8")
      val a = java.net.URLEncoder.encode(amount, "UTF-8")
      return "send_money?payee=$p&upi=$u&amount=$a"
    }
  }
  object UpiPin : Screen("upi_pin?payee={payee}&upi={upi}&amount={amount}&note={note}") {
    fun createRoute(payee: String, upi: String, amount: String, note: String): String {
      val p = java.net.URLEncoder.encode(payee, "UTF-8")
      val u = java.net.URLEncoder.encode(upi, "UTF-8")
      val a = java.net.URLEncoder.encode(amount, "UTF-8")
      val n = java.net.URLEncoder.encode(note, "UTF-8")
      return "upi_pin?payee=$p&upi=$u&amount=$a&note=$n"
    }
  }
  object PaymentSuccess : Screen("payment_success?txnId={txnId}") {
    fun createRoute(txnId: String) = "payment_success?txnId=${java.net.URLEncoder.encode(txnId, "UTF-8")}"
  }
  object QrScanner : Screen("qr_scanner")
  object AddMoney : Screen("add_money")
  object Settings : Screen("settings")
  object SavingsVault : Screen("savings_vault")
}
