package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MockData
import com.example.model.BankAccount
import com.example.model.RecentPayee
import com.example.model.SavingsGoal
import com.example.model.Transaction
import com.example.model.TransactionCategory
import com.example.model.TransactionStatus
import com.example.model.TransactionType
import com.example.model.UserProfile
import com.example.model.VirtualCard
import com.example.utils.FintechUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.ceil

data class AppUiState(
  val isLoggedIn: Boolean = true, // Logged in by default for preview, can logout to test auth
  val user: UserProfile = MockData.defaultUser,
  val totalBalance: Double = 48750.00,
  val savingsBalance: Double = 18400.00,
  val transactions: List<Transaction> = MockData.getInitialTransactions(),
  val cards: List<VirtualCard> = MockData.initialCards,
  val bankAccounts: List<BankAccount> = MockData.initialBankAccounts,
  val savingsGoals: List<SavingsGoal> = MockData.initialSavingsGoals,
  val recentPayees: List<RecentPayee> = MockData.recentPayees,
  val isBalanceVisible: Boolean = true,
  val isDarkMode: Boolean = false,
  val notificationsEnabled: Boolean = true,
  val biometricEnabled: Boolean = true,
  val roundUpSavingsEnabled: Boolean = true,
  val appLanguage: String = "English",
  val lastTransaction: Transaction? = null
)

class AppViewModel : ViewModel() {

  private val _uiState = MutableStateFlow(AppUiState())
  val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

  fun login(identifier: String) {
    _uiState.update { state ->
      state.copy(
        isLoggedIn = true,
        user = state.user.copy(
          email = if (identifier.contains("@")) identifier else state.user.email,
          phone = if (!identifier.contains("@") && identifier.isNotBlank()) identifier else state.user.phone
        )
      )
    }
  }

  fun signUp(name: String, phone: String, email: String) {
    _uiState.update { state ->
      state.copy(
        isLoggedIn = true,
        user = UserProfile(
          name = name.ifBlank { "Alex Morgan" },
          phone = phone.ifBlank { "+91 98765 43210" },
          email = email.ifBlank { "alex.morgan@email.com" },
          upiId = "${name.lowercase().replace(" ", "")}@smartsavingpay",
          isKycVerified = true
        )
      )
    }
  }

  fun logout() {
    _uiState.update { it.copy(isLoggedIn = false) }
  }

  fun toggleBalanceVisibility() {
    _uiState.update { it.copy(isBalanceVisible = !it.isBalanceVisible) }
  }

  fun toggleDarkMode() {
    _uiState.update { it.copy(isDarkMode = !it.isDarkMode) }
  }

  fun toggleNotifications(enabled: Boolean) {
    _uiState.update { it.copy(notificationsEnabled = enabled) }
  }

  fun toggleBiometric(enabled: Boolean) {
    _uiState.update { it.copy(biometricEnabled = enabled) }
  }

  fun toggleRoundUpSavings(enabled: Boolean) {
    _uiState.update { it.copy(roundUpSavingsEnabled = enabled) }
  }

  fun setLanguage(language: String) {
    _uiState.update { it.copy(appLanguage = language) }
  }

  fun updateProfile(name: String, phone: String, email: String) {
    _uiState.update { state ->
      state.copy(
        user = state.user.copy(
          name = name,
          phone = phone,
          email = email
        )
      )
    }
  }

  fun sendPayment(
    recipientName: String,
    upiId: String,
    amount: Double,
    note: String
  ): Transaction {
    val state = _uiState.value
    val newTxnId = FintechUtils.generateTxnId()
    val newRefId = FintechUtils.generateUpiRefId()
    val timestamp = System.currentTimeMillis()

    // Calculate smart round up if enabled
    var roundUpAmount = 0.0
    if (state.roundUpSavingsEnabled && amount > 10.0) {
      val nextMultiple = (ceil(amount / 10.0) * 10.0)
      val diff = nextMultiple - amount
      roundUpAmount = if (diff > 0.0) diff else 10.0
    }

    val primaryTxn = Transaction(
      id = newTxnId,
      title = recipientName.ifBlank { "Payment to $upiId" },
      subtitle = if (upiId.isNotBlank()) "UPI to $upiId" else "Direct transfer",
      amount = amount,
      type = TransactionType.DEBIT,
      category = TransactionCategory.TRANSFER,
      timestamp = timestamp,
      recipientOrSender = recipientName.ifBlank { upiId },
      upiId = upiId,
      status = TransactionStatus.SUCCESS,
      referenceId = newRefId,
      note = note
    )

    val updatedTxns = mutableListOf<Transaction>()
    updatedTxns.add(primaryTxn)

    var newSavings = state.savingsBalance
    if (roundUpAmount > 0) {
      val roundUpTxn = Transaction(
        id = FintechUtils.generateTxnId(),
        title = "Smart Round-Up Savings",
        subtitle = "Auto-saved on payment to $recipientName",
        amount = roundUpAmount,
        type = TransactionType.SAVINGS_ROUNDUP,
        category = TransactionCategory.SAVINGS,
        timestamp = timestamp + 100,
        recipientOrSender = "Smart Savings Vault",
        upiId = "savings@smartsavingpay",
        status = TransactionStatus.SUCCESS,
        referenceId = FintechUtils.generateUpiRefId(),
        note = "Round-up auto-deposit"
      )
      updatedTxns.add(roundUpTxn)
      newSavings += roundUpAmount
    }

    updatedTxns.addAll(state.transactions)

    val newTotal = (state.totalBalance - amount - roundUpAmount).coerceAtLeast(0.0)

    _uiState.update { s ->
      s.copy(
        totalBalance = newTotal,
        savingsBalance = newSavings,
        transactions = updatedTxns,
        lastTransaction = primaryTxn
      )
    }

    return primaryTxn
  }

  fun addMoney(amount: Double, paymentMethod: String): Transaction {
    val state = _uiState.value
    val newTxnId = FintechUtils.generateTxnId()
    val newRefId = FintechUtils.generateUpiRefId()
    val timestamp = System.currentTimeMillis()

    val txn = Transaction(
      id = newTxnId,
      title = "Money Added to Wallet",
      subtitle = "Added via $paymentMethod",
      amount = amount,
      type = TransactionType.CREDIT,
      category = TransactionCategory.TRANSFER,
      timestamp = timestamp,
      recipientOrSender = paymentMethod,
      upiId = "wallet.load@smartsavingpay",
      status = TransactionStatus.SUCCESS,
      referenceId = newRefId,
      note = "Wallet Top-up"
    )

    val updated = listOf(txn) + state.transactions
    val newTotal = state.totalBalance + amount

    _uiState.update { s ->
      s.copy(
        totalBalance = newTotal,
        transactions = updated,
        lastTransaction = txn
      )
    }

    return txn
  }

  fun transferToSavings(amount: Double): Boolean {
    val state = _uiState.value
    if (state.totalBalance < amount) return false

    val newTxnId = FintechUtils.generateTxnId()
    val txn = Transaction(
      id = newTxnId,
      title = "Deposit to Savings Vault",
      subtitle = "Smart Vault Earning 7.2% APY",
      amount = amount,
      type = TransactionType.SAVINGS_ROUNDUP,
      category = TransactionCategory.SAVINGS,
      timestamp = System.currentTimeMillis(),
      recipientOrSender = "Smart Savings Vault",
      upiId = "vault@smartsavingpay",
      status = TransactionStatus.SUCCESS,
      referenceId = FintechUtils.generateUpiRefId(),
      note = "Goal deposit"
    )

    _uiState.update { s ->
      s.copy(
        totalBalance = s.totalBalance - amount,
        savingsBalance = s.savingsBalance + amount,
        transactions = listOf(txn) + s.transactions
      )
    }
    return true
  }

  fun toggleCardFreeze(cardId: String) {
    _uiState.update { state ->
      state.copy(
        cards = state.cards.map { card ->
          if (card.id == cardId) card.copy(isFrozen = !card.isFrozen) else card
        }
      )
    }
  }

  fun toggleCardOnline(cardId: String) {
    _uiState.update { state ->
      state.copy(
        cards = state.cards.map { card ->
          if (card.id == cardId) card.copy(onlineEnabled = !card.onlineEnabled) else card
        }
      )
    }
  }

  fun toggleCardInternational(cardId: String) {
    _uiState.update { state ->
      state.copy(
        cards = state.cards.map { card ->
          if (card.id == cardId) card.copy(internationalEnabled = !card.internationalEnabled) else card
        }
      )
    }
  }

  fun addBankAccount(bankName: String, accountNumber: String, ifsc: String) {
    val last4 = if (accountNumber.length >= 4) accountNumber.takeLast(4) else "1234"
    val newAccount = BankAccount(
      id = "bank_${System.currentTimeMillis()}",
      bankName = bankName,
      accountNumberMasked = "•••• •••• $last4",
      ifsc = ifsc.uppercase(),
      isPrimary = false,
      balance = 25000.0
    )
    _uiState.update { state ->
      state.copy(bankAccounts = state.bankAccounts + newAccount)
    }
  }

  fun addSavingsGoal(title: String, targetAmount: Double, emoji: String) {
    val newGoal = SavingsGoal(
      id = "goal_${System.currentTimeMillis()}",
      title = title,
      targetAmount = targetAmount,
      currentAmount = 0.0,
      iconEmoji = emoji.ifBlank { "🎯" }
    )
    _uiState.update { state ->
      state.copy(savingsGoals = state.savingsGoals + newGoal)
    }
  }

  fun registerDemoUser(name: String, phone: String, email: String) {
    signUp(name, phone, email)
  }

  fun loginDemoUser(identifier: String) {
    login(identifier)
  }

  fun sendMoney(recipientName: String, upiId: String, amount: Double, note: String): Transaction {
    return sendPayment(recipientName, upiId, amount, note)
  }

  fun depositToVault(amount: Double): Boolean {
    return transferToSavings(amount)
  }

  fun withdrawFromVault(amount: Double): Boolean {
    val state = _uiState.value
    if (state.savingsBalance < amount) return false

    val newTxnId = FintechUtils.generateTxnId()
    val txn = Transaction(
      id = newTxnId,
      title = "Withdrawal from Savings Vault",
      subtitle = "Transferred to Primary Wallet",
      amount = amount,
      type = TransactionType.CREDIT,
      category = TransactionCategory.SAVINGS,
      timestamp = System.currentTimeMillis(),
      recipientOrSender = "Smart Savings Vault",
      upiId = "vault@smartsavingpay",
      status = TransactionStatus.SUCCESS,
      referenceId = FintechUtils.generateUpiRefId(),
      note = "Vault withdrawal"
    )

    _uiState.update { s ->
      s.copy(
        totalBalance = s.totalBalance + amount,
        savingsBalance = s.savingsBalance - amount,
        transactions = listOf(txn) + s.transactions
      )
    }
    return true
  }

  fun resetToDemoState() {
    _uiState.value = AppUiState()
  }
}
