package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.navigation.Screen
import com.example.screens.AddMoneyScreen
import com.example.screens.LoginScreen
import com.example.screens.MainDashboardContainer
import com.example.screens.OnboardingScreen
import com.example.screens.OtpScreen
import com.example.screens.PaymentSuccessScreen
import com.example.screens.QrScannerScreen
import com.example.screens.SavingsVaultScreen
import com.example.screens.SendMoneyScreen
import com.example.screens.SettingsScreen
import com.example.screens.SignUpScreen
import com.example.screens.SplashScreen
import com.example.screens.UpiPinScreen
import com.example.ui.theme.SmartSavingPayTheme
import com.example.viewmodel.AppViewModel
import java.net.URLDecoder

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      SmartSavingPayTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background
        ) {
          SmartSavingPayApp()
        }
      }
    }
  }
}

@Composable
fun SmartSavingPayApp(
  appViewModel: AppViewModel = viewModel()
) {
  val navController = rememberNavController()
  val uiState by appViewModel.uiState.collectAsState()

  NavHost(
    navController = navController,
    startDestination = Screen.Splash.route
  ) {
    // 1. Splash Screen
    composable(Screen.Splash.route) {
      SplashScreen(
        onNavigateNext = {
          navController.navigate(Screen.Onboarding.route) {
            popUpTo(Screen.Splash.route) { inclusive = true }
          }
        }
      )
    }

    // 2. Onboarding Screen
    composable(Screen.Onboarding.route) {
      OnboardingScreen(
        onGetStarted = {
          navController.navigate(Screen.SignUp.route)
        },
        onLoginClick = {
          navController.navigate(Screen.Login.route)
        }
      )
    }

    // 3. Sign Up Screen
    composable(Screen.SignUp.route) {
      SignUpScreen(
        onNavigateToOtp = { phone ->
          navController.navigate(Screen.Otp.createRoute(phone))
        },
        onNavigateToLogin = {
          navController.navigate(Screen.Login.route)
        },
        onBack = {
          navController.popBackStack()
        },
        onRegisterDemo = { name, phone, email ->
          appViewModel.registerDemoUser(name, phone, email)
        }
      )
    }

    // 4. Login Screen
    composable(Screen.Login.route) {
      LoginScreen(
        onLoginSuccess = { identifier ->
          appViewModel.loginDemoUser(identifier)
          navController.navigate(Screen.Main.createRoute("home")) {
            popUpTo(Screen.Onboarding.route) { inclusive = true }
          }
        },
        onNavigateToSignUp = {
          navController.navigate(Screen.SignUp.route)
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }

    // 5. OTP Verification Screen
    composable(
      route = Screen.Otp.route,
      arguments = listOf(navArgument("phone") { type = NavType.StringType; defaultValue = "" })
    ) { backStackEntry ->
      val rawPhone = backStackEntry.arguments?.getString("phone") ?: ""
      val phone = try { URLDecoder.decode(rawPhone, "UTF-8") } catch (e: Exception) { rawPhone }

      OtpScreen(
        phone = phone,
        onVerifySuccess = {
          navController.navigate(Screen.Main.createRoute("home")) {
            popUpTo(Screen.Onboarding.route) { inclusive = true }
          }
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }

    // 6. Main Dashboard Container (Home, History, Cards, Profile tabs)
    composable(
      route = Screen.Main.route,
      arguments = listOf(navArgument("tab") { type = NavType.StringType; defaultValue = "home" })
    ) { backStackEntry ->
      val initialTab = backStackEntry.arguments?.getString("tab") ?: "home"

      MainDashboardContainer(
        uiState = uiState,
        initialTab = initialTab,
        onToggleBalanceVisibility = {
          appViewModel.toggleBalanceVisibility()
        },
        onNavigateToSendMoney = { payee, upi, amount ->
          navController.navigate(Screen.SendMoney.createRoute(payee, upi, amount))
        },
        onNavigateToAddMoney = {
          navController.navigate(Screen.AddMoney.route)
        },
        onNavigateToScanPay = {
          navController.navigate(Screen.QrScanner.route)
        },
        onNavigateToSavingsVault = {
          navController.navigate(Screen.SavingsVault.route)
        },
        onNavigateToSettings = {
          navController.navigate(Screen.Settings.route)
        },
        onToggleCardFreeze = { cardId ->
          appViewModel.toggleCardFreeze(cardId)
        },
        onToggleCardOnline = { cardId ->
          appViewModel.toggleCardOnline(cardId)
        },
        onToggleCardInternational = { cardId ->
          appViewModel.toggleCardInternational(cardId)
        },
        onAddBankAccount = { bankName, accNo, ifsc ->
          appViewModel.addBankAccount(bankName, accNo, ifsc)
        },
        onUpdateProfile = { name, phone, email ->
          appViewModel.updateProfile(name, phone, email)
        },
        onLogout = {
          appViewModel.logout()
          navController.navigate(Screen.Onboarding.route) {
            popUpTo(Screen.Main.route) { inclusive = true }
          }
        }
      )
    }

    // 7. Send Money Screen
    composable(
      route = Screen.SendMoney.route,
      arguments = listOf(
        navArgument("payee") { type = NavType.StringType; defaultValue = "" },
        navArgument("upi") { type = NavType.StringType; defaultValue = "" },
        navArgument("amount") { type = NavType.StringType; defaultValue = "" }
      )
    ) { backStackEntry ->
      val rawPayee = backStackEntry.arguments?.getString("payee") ?: ""
      val rawUpi = backStackEntry.arguments?.getString("upi") ?: ""
      val rawAmount = backStackEntry.arguments?.getString("amount") ?: ""

      val payee = try { URLDecoder.decode(rawPayee, "UTF-8") } catch (e: Exception) { rawPayee }
      val upi = try { URLDecoder.decode(rawUpi, "UTF-8") } catch (e: Exception) { rawUpi }
      val amount = try { URLDecoder.decode(rawAmount, "UTF-8") } catch (e: Exception) { rawAmount }

      SendMoneyScreen(
        uiState = uiState,
        initialPayee = payee,
        initialUpi = upi,
        initialAmount = amount,
        onNavigateToUpiPin = { p, u, a, n ->
          navController.navigate(Screen.UpiPin.createRoute(p, u, a, n))
        },
        onNavigateToScanQr = {
          navController.navigate(Screen.QrScanner.route)
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }

    // 8. UPI PIN Screen
    composable(
      route = Screen.UpiPin.route,
      arguments = listOf(
        navArgument("payee") { type = NavType.StringType; defaultValue = "" },
        navArgument("upi") { type = NavType.StringType; defaultValue = "" },
        navArgument("amount") { type = NavType.StringType; defaultValue = "0" },
        navArgument("note") { type = NavType.StringType; defaultValue = "" }
      )
    ) { backStackEntry ->
      val rawPayee = backStackEntry.arguments?.getString("payee") ?: ""
      val rawUpi = backStackEntry.arguments?.getString("upi") ?: ""
      val rawAmount = backStackEntry.arguments?.getString("amount") ?: "0"
      val rawNote = backStackEntry.arguments?.getString("note") ?: ""

      val payee = try { URLDecoder.decode(rawPayee, "UTF-8") } catch (e: Exception) { rawPayee }
      val upi = try { URLDecoder.decode(rawUpi, "UTF-8") } catch (e: Exception) { rawUpi }
      val amount = try { URLDecoder.decode(rawAmount, "UTF-8") } catch (e: Exception) { rawAmount }
      val note = try { URLDecoder.decode(rawNote, "UTF-8") } catch (e: Exception) { rawNote }

      UpiPinScreen(
        payee = payee,
        upi = upi,
        amount = amount,
        note = note,
        onPaymentConfirmed = { recipient, upiId, amt, n ->
          appViewModel.sendMoney(recipient, upiId, amt, n)
        },
        onNavigateToSuccess = { txnId ->
          navController.navigate(Screen.PaymentSuccess.createRoute(txnId)) {
            popUpTo(Screen.SendMoney.route) { inclusive = true }
          }
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }

    // 9. Payment Success Screen
    composable(
      route = Screen.PaymentSuccess.route,
      arguments = listOf(navArgument("txnId") { type = NavType.StringType; defaultValue = "" })
    ) { backStackEntry ->
      val rawTxnId = backStackEntry.arguments?.getString("txnId") ?: ""
      val txnId = try { URLDecoder.decode(rawTxnId, "UTF-8") } catch (e: Exception) { rawTxnId }

      PaymentSuccessScreen(
        txnId = txnId,
        uiState = uiState,
        onDone = {
          navController.navigate(Screen.Main.createRoute("home")) {
            popUpTo(Screen.Main.route) { inclusive = true }
          }
        },
        onViewTransaction = { _ ->
          navController.navigate(Screen.Main.createRoute("transactions")) {
            popUpTo(Screen.Main.route) { inclusive = true }
          }
        }
      )
    }

    // 10. QR Scanner Screen
    composable(Screen.QrScanner.route) {
      QrScannerScreen(
        onQrScanned = { name, upiId, amount ->
          navController.navigate(Screen.SendMoney.createRoute(name, upiId, amount)) {
            popUpTo(Screen.QrScanner.route) { inclusive = true }
          }
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }

    // 11. Add Money Screen
    composable(Screen.AddMoney.route) {
      AddMoneyScreen(
        uiState = uiState,
        onAddMoneyConfirmed = { amount, source ->
          appViewModel.addMoney(amount, source)
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }

    // 12. Savings Vault Screen
    composable(Screen.SavingsVault.route) {
      SavingsVaultScreen(
        uiState = uiState,
        onToggleRoundUp = { enabled ->
          appViewModel.toggleRoundUpSavings(enabled)
        },
        onWithdrawToWallet = { amount ->
          appViewModel.withdrawFromVault(amount)
        },
        onDepositToVault = { amount ->
          appViewModel.depositToVault(amount)
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }

    // 13. Settings Screen
    composable(Screen.Settings.route) {
      SettingsScreen(
        uiState = uiState,
        onToggleBiometric = { enabled ->
          appViewModel.toggleBiometric(enabled)
        },
        onToggleRoundUp = { enabled ->
          appViewModel.toggleRoundUpSavings(enabled)
        },
        onResetDemoData = {
          appViewModel.resetToDemoState()
        },
        onBack = {
          navController.popBackStack()
        }
      )
    }
  }
}
