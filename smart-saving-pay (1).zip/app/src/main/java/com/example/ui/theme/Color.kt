package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FintechPrimary = Color(0xFF0066FF)
val FintechPrimaryLight = Color(0xFF3B82F6)
val FintechPrimaryDark = Color(0xFF0047B3)

val FintechNavy = Color(0xFF0B192C)
val FintechNavySurface = Color(0xFF1E2A38)
val FintechNavyLight = Color(0xFF1E3E62)

val FintechSecondary = Color(0xFF10B981) // Emerald Savings Green
val FintechSecondaryLight = Color(0xFF34D399)
val FintechSecondaryDark = Color(0xFF059669)

val FintechAccent = Color(0xFF6366F1) // Indigo
val FintechGold = Color(0xFFF59E0B) // Amber
val FintechRose = Color(0xFFEF4444) // Expense Red

val FintechBackgroundLight = Color(0xFFF8FAFC)
val FintechSurfaceLight = Color(0xFFFFFFFF)
val FintechSurfaceElevatedLight = Color(0xFFF1F5F9)
val FintechTextPrimaryLight = Color(0xFF0F172A)
val FintechTextSecondaryLight = Color(0xFF64748B)
val FintechBorderLight = Color(0xFFE2E8F0)

val FintechBackgroundDark = Color(0xFF0A0F1D)
val FintechSurfaceDark = Color(0xFF131B2E)
val FintechSurfaceElevatedDark = Color(0xFF1E293B)
val FintechTextPrimaryDark = Color(0xFFF8FAFC)
val FintechTextSecondaryDark = Color(0xFF94A3B8)
val FintechBorderDark = Color(0xFF1E293B)
