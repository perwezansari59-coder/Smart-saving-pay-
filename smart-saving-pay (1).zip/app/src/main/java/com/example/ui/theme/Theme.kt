package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = FintechPrimaryLight,
  onPrimary = Color.White,
  primaryContainer = FintechNavyLight,
  onPrimaryContainer = Color.White,
  secondary = FintechSecondaryLight,
  onSecondary = Color.Black,
  secondaryContainer = FintechSecondaryDark,
  onSecondaryContainer = Color.White,
  tertiary = FintechGold,
  onTertiary = Color.Black,
  background = FintechBackgroundDark,
  onBackground = FintechTextPrimaryDark,
  surface = FintechSurfaceDark,
  onSurface = FintechTextPrimaryDark,
  surfaceVariant = FintechSurfaceElevatedDark,
  onSurfaceVariant = FintechTextSecondaryDark,
  outline = FintechBorderDark,
  error = FintechRose,
  onError = Color.White
)

private val LightColorScheme = lightColorScheme(
  primary = FintechPrimary,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE0E7FF),
  onPrimaryContainer = FintechPrimaryDark,
  secondary = FintechSecondary,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFD1FAE5),
  onSecondaryContainer = FintechSecondaryDark,
  tertiary = FintechGold,
  onTertiary = Color.White,
  background = FintechBackgroundLight,
  onBackground = FintechTextPrimaryLight,
  surface = FintechSurfaceLight,
  onSurface = FintechTextPrimaryLight,
  surfaceVariant = FintechSurfaceElevatedLight,
  onSurfaceVariant = FintechTextSecondaryLight,
  outline = FintechBorderLight,
  error = FintechRose,
  onError = Color.White
)

@Composable
fun SmartSavingPayTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
