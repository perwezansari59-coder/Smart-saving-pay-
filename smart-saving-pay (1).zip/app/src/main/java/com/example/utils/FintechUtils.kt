package com.example.utils

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object FintechUtils {
  private val currencyFormat: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 2
    minimumFractionDigits = 2
  }

  fun formatCurrency(amount: Double): String {
    // Return formatted string with ₹ symbol
    return try {
      currencyFormat.format(amount)
    } catch (_: Exception) {
      String.format(Locale.US, "₹%.2f", amount)
    }
  }

  fun formatCurrencyNoDecimals(amount: Double): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
      maximumFractionDigits = 0
    }
    return try {
      formatter.format(amount)
    } catch (_: Exception) {
      String.format(Locale.US, "₹%.0f", amount)
    }
  }

  fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
  }

  fun formatShortDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    return sdf.format(Date(timestamp))
  }

  fun formatTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
  }

  fun generateTxnId(): String {
    val randomNum = Random.nextLong(1000000000L, 9999999999L)
    return "TXN$randomNum"
  }

  fun generateUpiRefId(): String {
    val randomNum = Random.nextLong(100000000000L, 999999999999L)
    return "UPI/$randomNum"
  }
}
