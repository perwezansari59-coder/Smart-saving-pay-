package com.example.model

enum class TransactionType {
  DEBIT,
  CREDIT,
  SAVINGS_ROUNDUP
}

enum class TransactionCategory {
  SHOPPING,
  FOOD_DINING,
  TRANSFER,
  SALARY,
  BILLS_UTILITIES,
  SAVINGS,
  ENTERTAINMENT,
  INVESTMENT
}

enum class TransactionStatus {
  SUCCESS,
  PENDING,
  FAILED
}

data class Transaction(
  val id: String,
  val title: String,
  val subtitle: String,
  val amount: Double,
  val type: TransactionType,
  val category: TransactionCategory,
  val timestamp: Long,
  val recipientOrSender: String,
  val upiId: String = "",
  val status: TransactionStatus = TransactionStatus.SUCCESS,
  val referenceId: String = "",
  val note: String = ""
)

data class BankAccount(
  val id: String,
  val bankName: String,
  val accountNumberMasked: String,
  val ifsc: String,
  val isPrimary: Boolean = false,
  val balance: Double
)

data class VirtualCard(
  val id: String,
  val cardNumberMasked: String,
  val fullCardNumber: String,
  val cardHolder: String,
  val expiryDate: String,
  val cvv: String,
  val cardType: String = "RuPay Platinum Virtual",
  val isFrozen: Boolean = false,
  val onlineEnabled: Boolean = true,
  val internationalEnabled: Boolean = false,
  val dailyLimit: Double = 50000.0
)

data class UserProfile(
  val name: String,
  val phone: String,
  val email: String,
  val upiId: String,
  val isKycVerified: Boolean = true
)

data class RecentPayee(
  val name: String,
  val upiId: String,
  val phone: String,
  val avatarInitials: String,
  val avatarColor: Long
)

data class SavingsGoal(
  val id: String,
  val title: String,
  val targetAmount: Double,
  val currentAmount: Double,
  val iconEmoji: String
)
