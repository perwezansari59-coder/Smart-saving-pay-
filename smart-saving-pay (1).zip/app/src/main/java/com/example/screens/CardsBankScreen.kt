package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.VirtualDebitCardView
import com.example.model.BankAccount
import com.example.model.VirtualCard
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechRose
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils
import com.example.viewmodel.AppUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardsBankScreen(
  uiState: AppUiState,
  onToggleCardFreeze: (cardId: String) -> Unit,
  onToggleCardOnline: (cardId: String) -> Unit,
  onToggleCardInternational: (cardId: String) -> Unit,
  onAddBankAccount: (bankName: String, accountNo: String, ifsc: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var showCardDetails by remember { mutableStateOf(false) }
  var showAddBankDialog by remember { mutableStateOf(false) }
  var newBankName by remember { mutableStateOf("") }
  var newAccountNo by remember { mutableStateOf("") }
  var newIfsc by remember { mutableStateOf("") }
  var checkBalanceNotice by remember { mutableStateOf<String?>(null) }

  val primaryCard = uiState.cards.firstOrNull()

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Cards & Bank Accounts", fontWeight = FontWeight.Bold) },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("cards_bank_screen_root")
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 20.dp),
      contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
      // Demo security note
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = FintechPrimary.copy(alpha = 0.08f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Info, contentDescription = null, tint = FintechPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "Demo Virtual Cards & Accounts: All card numbers, limits, and accounts are simulated for this prototype.",
              fontSize = 11.sp,
              color = FintechPrimary,
              lineHeight = 16.sp
            )
          }
        }
      }

      // Virtual Card Visual
      if (primaryCard != null) {
        item {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Virtual Debit Card",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground
              )
              TextButton(onClick = { showCardDetails = !showCardDetails }) {
                Text(
                  text = if (showCardDetails) "Hide Numbers" else "Show Details",
                  color = FintechPrimary,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            VirtualDebitCardView(
              card = primaryCard,
              showDetails = showCardDetails,
              onToggleDetails = { showCardDetails = !showCardDetails }
            )
          }
        }

        // Card Controls
        item {
          Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("Card Security & Limits", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Spacer(modifier = Modifier.height(12.dp))

              // Freeze Switch
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    Icons.Default.Lock,
                    contentDescription = null,
                    tint = if (primaryCard.isFrozen) FintechRose else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text("Freeze Virtual Card", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Instantly block all card transactions", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
                Switch(
                  checked = primaryCard.isFrozen,
                  onCheckedChange = { onToggleCardFreeze(primaryCard.id) },
                  colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = FintechRose),
                  modifier = Modifier.testTag("switch_freeze_card")
                )
              }

              HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

              // Online Transactions Switch
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = FintechPrimary, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text("Online Purchases", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Enable e-commerce and app payments", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
                Switch(
                  checked = primaryCard.onlineEnabled,
                  onCheckedChange = { onToggleCardOnline(primaryCard.id) },
                  colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = FintechPrimary),
                  modifier = Modifier.testTag("switch_online_card")
                )
              }

              HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

              // International Usage
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Public, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text("International Usage", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Worldwide POS and online payments", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
                Switch(
                  checked = primaryCard.internationalEnabled,
                  onCheckedChange = { onToggleCardInternational(primaryCard.id) },
                  colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF8B5CF6)),
                  modifier = Modifier.testTag("switch_international_card")
                )
              }
            }
          }
        }
      }

      // Linked Bank Accounts Section
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Linked Bank Accounts",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onBackground
          )
          TextButton(
            onClick = { showAddBankDialog = true },
            modifier = Modifier.testTag("add_bank_account_button")
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add Bank", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          }
        }
      }

      if (checkBalanceNotice != null) {
        item {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = FintechSecondary.copy(alpha = 0.15f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = checkBalanceNotice!!,
              color = FintechSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(12.dp)
            )
          }
        }
      }

      items(uiState.bankAccounts) { account ->
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .background(FintechPrimary.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.AccountBalance, contentDescription = null, tint = FintechPrimary)
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(account.bankName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  if (account.isPrimary) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = FintechSecondary.copy(alpha = 0.2f)
                    ) {
                      Text(
                        text = "PRIMARY",
                        color = FintechSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
                Text("A/C: ${account.accountNumberMasked}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("IFSC: ${account.ifsc}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            OutlinedButton(
              onClick = {
                val balanceToShow = if (account.isPrimary) uiState.totalBalance else account.balance
                checkBalanceNotice = "${account.bankName} balance: ${FintechUtils.formatCurrency(balanceToShow)}"
              },
              shape = RoundedCornerShape(10.dp)
            ) {
              Text("Balance", fontSize = 11.sp)
            }
          }
        }
      }
    }
  }

  // Add Bank Account Dialog
  if (showAddBankDialog) {
    AlertDialog(
      onDismissRequest = { showAddBankDialog = false },
      title = { Text("Link Bank Account (Demo)", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Link your demo bank account to transfer funds locally.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          OutlinedTextField(
            value = newBankName,
            onValueChange = { newBankName = it },
            label = { Text("Bank Name (e.g. ICICI Bank)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = newAccountNo,
            onValueChange = { newAccountNo = it },
            label = { Text("Account Number") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = newIfsc,
            onValueChange = { newIfsc = it },
            label = { Text("IFSC Code (e.g. ICIC0001092)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (newBankName.isNotBlank() && newAccountNo.isNotBlank()) {
              onAddBankAccount(newBankName, newAccountNo, newIfsc.ifBlank { "DEMO0001" })
              showAddBankDialog = false
              newBankName = ""
              newAccountNo = ""
              newIfsc = ""
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary)
        ) {
          Text("Link Account")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddBankDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}
