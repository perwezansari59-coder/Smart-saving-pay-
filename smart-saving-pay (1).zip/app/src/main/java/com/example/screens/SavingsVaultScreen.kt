package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FintechGold
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechRose
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils
import com.example.viewmodel.AppUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavingsVaultScreen(
  uiState: AppUiState,
  onToggleRoundUp: (Boolean) -> Unit,
  onWithdrawToWallet: (Double) -> Boolean,
  onDepositToVault: (Double) -> Boolean,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showWithdrawDialog by remember { mutableStateOf(false) }
  var showDepositDialog by remember { mutableStateOf(false) }
  var amountText by remember { mutableStateOf("") }
  var dialogError by remember { mutableStateOf<String?>(null) }
  var toastMessage by remember { mutableStateOf<String?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Smart Savings Vault", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("vault_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("savings_vault_screen_root")
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 20.dp),
      contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Vault Balance Hero Banner
      item {
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = Color.Transparent),
          elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                Brush.linearGradient(
                  colors = listOf(
                    Color(0xFF0F766E),
                    Color(0xFF059669),
                    Color(0xFF10B981)
                  )
                )
              )
              .padding(22.dp)
          ) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Savings, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("High-Yield Micro Vault", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }

                Surface(
                  shape = RoundedCornerShape(100.dp),
                  color = Color.White.copy(alpha = 0.2f)
                ) {
                  Text(
                    text = "7.2% APY",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(18.dp))

              Text("Total Savings Balance", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = FintechUtils.formatCurrency(uiState.savingsBalance),
                color = Color.White,
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold
              )

              Spacer(modifier = Modifier.height(8.dp))

              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = FintechGold, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "+₹248.60 interest accrued this month",
                  color = Color.White.copy(alpha = 0.95f),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Medium
                )
              }

              Spacer(modifier = Modifier.height(20.dp))

              // Vault Quick Action Buttons
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Button(
                  onClick = {
                    amountText = ""
                    dialogError = null
                    showDepositDialog = true
                  },
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                  modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("vault_deposit_button")
                ) {
                  Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Deposit", color = Color(0xFF059669), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Button(
                  onClick = {
                    amountText = ""
                    dialogError = null
                    showWithdrawDialog = true
                  },
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.25f)),
                  modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("vault_withdraw_button")
                ) {
                  Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Withdraw", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
              }
            }
          }
        }
      }

      if (toastMessage != null) {
        item {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = FintechSecondary.copy(alpha = 0.15f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = toastMessage!!,
              color = FintechSecondary,
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(12.dp)
            )
          }
        }
      }

      // 2. Smart Auto-Roundup Switch Card
      item {
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .background(FintechSecondary.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Bolt, contentDescription = null, tint = FintechSecondary, modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text("Automatic Round-Up", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text("Round payments to nearest ₹10 or ₹100", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Switch(
                checked = uiState.roundUpSavingsEnabled,
                onCheckedChange = { onToggleRoundUp(it) },
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = FintechSecondary),
                modifier = Modifier.testTag("switch_auto_roundup")
              )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = "Example: When you pay ₹220 at a coffee shop, ₹80 spare change is automatically transferred into your 7.2% APY Vault without feeling any pinch!",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              lineHeight = 17.sp
            )
          }
        }
      }

      // 3. Savings Goals Progress
      item {
        Text("Your Active Savings Goals", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
      }

      // Goal 1: Emergency Fund
      item {
        GoalCard(
          icon = Icons.Default.Savings,
          iconColor = FintechSecondary,
          title = "Emergency Safety Net",
          savedAmount = 38500.0,
          targetAmount = 50000.0,
          category = "Safety"
        )
      }

      // Goal 2: Bali Vacation
      item {
        GoalCard(
          icon = Icons.Default.BeachAccess,
          iconColor = Color(0xFFF59E0B),
          title = "Bali Summer Vacation",
          savedAmount = 14200.0,
          targetAmount = 40000.0,
          category = "Travel"
        )
      }

      // Goal 3: Tech Upgrade
      item {
        GoalCard(
          icon = Icons.Default.Laptop,
          iconColor = FintechPrimary,
          title = "New MacBook Pro",
          savedAmount = 45000.0,
          targetAmount = 120000.0,
          category = "Gadgets"
        )
      }
    }
  }

  // Deposit Dialog
  if (showDepositDialog) {
    AlertDialog(
      onDismissRequest = { showDepositDialog = false },
      title = { Text("Deposit to Vault", fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text("Transfer funds from your wallet into the 7.2% APY savings vault:", fontSize = 12.sp)
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it; dialogError = null },
            label = { Text("Amount (₹)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          dialogError?.let { err ->
            Spacer(modifier = Modifier.height(6.dp))
            Text(err, color = FintechRose, fontSize = 12.sp)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amt = amountText.toDoubleOrNull()
            if (amt == null || amt <= 0.0) {
              dialogError = "Enter a valid amount"
              return@Button
            }
            if (amt > uiState.totalBalance) {
              dialogError = "Insufficient wallet balance"
              return@Button
            }
            if (onDepositToVault(amt)) {
              showDepositDialog = false
              toastMessage = "Deposited ${FintechUtils.formatCurrency(amt)} into Savings Vault!"
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = FintechSecondary)
        ) {
          Text("Confirm Deposit")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDepositDialog = false }) { Text("Cancel") }
      }
    )
  }

  // Withdraw Dialog
  if (showWithdrawDialog) {
    AlertDialog(
      onDismissRequest = { showWithdrawDialog = false },
      title = { Text("Withdraw to Wallet", fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text("Instant free withdrawal from your savings vault back into your primary wallet:", fontSize = 12.sp)
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it; dialogError = null },
            label = { Text("Amount (₹)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          dialogError?.let { err ->
            Spacer(modifier = Modifier.height(6.dp))
            Text(err, color = FintechRose, fontSize = 12.sp)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amt = amountText.toDoubleOrNull()
            if (amt == null || amt <= 0.0) {
              dialogError = "Enter a valid amount"
              return@Button
            }
            if (amt > uiState.savingsBalance) {
              dialogError = "Insufficient vault balance"
              return@Button
            }
            if (onWithdrawToWallet(amt)) {
              showWithdrawDialog = false
              toastMessage = "Withdrew ${FintechUtils.formatCurrency(amt)} to Wallet!"
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary)
        ) {
          Text("Confirm Withdrawal")
        }
      },
      dismissButton = {
        TextButton(onClick = { showWithdrawDialog = false }) { Text("Cancel") }
      }
    )
  }
}

@Composable
private fun GoalCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconColor: Color,
  title: String,
  savedAmount: Double,
  targetAmount: Double,
  category: String
) {
  val progress = (savedAmount / targetAmount).toFloat().coerceIn(0f, 1f)
  val percentage = (progress * 100).toInt()

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .background(iconColor.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
          ) {
            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(category, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        Text(
          text = "$percentage%",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = iconColor
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      LinearProgressIndicator(
        progress = { progress },
        color = iconColor,
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp))
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "Saved: ${FintechUtils.formatCurrency(savedAmount)}",
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = "Goal: ${FintechUtils.formatCurrency(targetAmount)}",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface
        )
      }
    }
  }
}
