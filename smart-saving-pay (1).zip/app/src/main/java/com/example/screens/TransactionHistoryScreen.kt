package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.TransactionDetailSheet
import com.example.components.TransactionItemCard
import com.example.model.Transaction
import com.example.model.TransactionType
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary
import com.example.viewmodel.AppUiState

enum class HistoryFilter {
  ALL,
  DEBITS,
  CREDITS,
  SAVINGS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionHistoryScreen(
  uiState: AppUiState,
  onNavigateToSendMoney: (payee: String, upi: String, amount: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedFilter by remember { mutableStateOf(HistoryFilter.ALL) }
  var selectedTransaction by remember { mutableStateOf<Transaction?>(null) }

  val filteredTransactions = uiState.transactions.filter { txn ->
    val matchesSearch = txn.title.contains(searchQuery, ignoreCase = true) ||
      txn.recipientOrSender.contains(searchQuery, ignoreCase = true) ||
      txn.subtitle.contains(searchQuery, ignoreCase = true) ||
      txn.upiId.contains(searchQuery, ignoreCase = true)

    val matchesFilter = when (selectedFilter) {
      HistoryFilter.ALL -> true
      HistoryFilter.DEBITS -> txn.type == TransactionType.DEBIT
      HistoryFilter.CREDITS -> txn.type == TransactionType.CREDIT
      HistoryFilter.SAVINGS -> txn.type == TransactionType.SAVINGS_ROUNDUP
    }

    matchesSearch && matchesFilter
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Transaction History", fontWeight = FontWeight.Bold)
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("history_screen_root")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 20.dp)
    ) {
      // Search Bar
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search by name, UPI ID, merchant...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Close, contentDescription = "Clear search")
            }
          }
        },
        shape = RoundedCornerShape(16.dp),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("history_search_input")
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Filter Chips
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        item {
          FilterChip(
            selected = selectedFilter == HistoryFilter.ALL,
            onClick = { selectedFilter = HistoryFilter.ALL },
            label = { Text("All (${uiState.transactions.size})") },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = FintechPrimary,
              selectedLabelColor = Color.White
            ),
            modifier = Modifier.testTag("filter_all")
          )
        }
        item {
          FilterChip(
            selected = selectedFilter == HistoryFilter.DEBITS,
            onClick = { selectedFilter = HistoryFilter.DEBITS },
            label = { Text("Debits") },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = FintechPrimary,
              selectedLabelColor = Color.White
            ),
            modifier = Modifier.testTag("filter_debits")
          )
        }
        item {
          FilterChip(
            selected = selectedFilter == HistoryFilter.CREDITS,
            onClick = { selectedFilter = HistoryFilter.CREDITS },
            label = { Text("Credits") },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = FintechSecondary,
              selectedLabelColor = Color.White
            ),
            modifier = Modifier.testTag("filter_credits")
          )
        }
        item {
          FilterChip(
            selected = selectedFilter == HistoryFilter.SAVINGS,
            onClick = { selectedFilter = HistoryFilter.SAVINGS },
            label = { Text("Savings Round-up") },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = FintechSecondary,
              selectedLabelColor = Color.White
            ),
            modifier = Modifier.testTag("filter_savings")
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Transactions List
      if (filteredTransactions.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(top = 48.dp),
          contentAlignment = Alignment.TopCenter
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("No transactions found", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text("Try clearing filters or making a transfer", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 32.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          items(filteredTransactions) { txn ->
            TransactionItemCard(
              transaction = txn,
              onClick = { selectedTransaction = txn }
            )
          }
        }
      }
    }
  }

  // Detail Sheet
  TransactionDetailSheet(
    transaction = selectedTransaction,
    onDismiss = { selectedTransaction = null },
    onRepeatPayment = { txn ->
      onNavigateToSendMoney(txn.recipientOrSender, txn.upiId, txn.amount.toString())
    }
  )
}
