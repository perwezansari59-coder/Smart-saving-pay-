package com.example.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Transaction
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary
import com.example.viewmodel.AppUiState

enum class DashboardTab {
  HOME,
  TRANSACTIONS,
  CARDS,
  PROFILE
}

@Composable
fun MainDashboardContainer(
  uiState: AppUiState,
  initialTab: String = "home",
  onToggleBalanceVisibility: () -> Unit,
  onNavigateToSendMoney: (payee: String, upi: String, amount: String) -> Unit,
  onNavigateToAddMoney: () -> Unit,
  onNavigateToScanPay: () -> Unit,
  onNavigateToSavingsVault: () -> Unit,
  onNavigateToSettings: () -> Unit,
  onToggleCardFreeze: (String) -> Unit,
  onToggleCardOnline: (String) -> Unit,
  onToggleCardInternational: (String) -> Unit,
  onAddBankAccount: (String, String, String) -> Unit,
  onUpdateProfile: (String, String, String) -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier
) {
  var currentTab by remember {
    mutableStateOf(
      when (initialTab.lowercase()) {
        "transactions", "history" -> DashboardTab.TRANSACTIONS
        "cards", "bank" -> DashboardTab.CARDS
        "profile" -> DashboardTab.PROFILE
        else -> DashboardTab.HOME
      }
    )
  }

  Scaffold(
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("main_bottom_nav")
      ) {
        // Home
        NavigationBarItem(
          selected = currentTab == DashboardTab.HOME,
          onClick = { currentTab = DashboardTab.HOME },
          icon = {
            Icon(
              imageVector = if (currentTab == DashboardTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
              contentDescription = "Home"
            )
          },
          label = {
            Text(
              "Home",
              fontSize = 11.sp,
              fontWeight = if (currentTab == DashboardTab.HOME) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = FintechPrimary,
            selectedTextColor = FintechPrimary,
            indicatorColor = FintechPrimary.copy(alpha = 0.12f)
          ),
          modifier = Modifier.testTag("nav_tab_home")
        )

        // Transactions
        NavigationBarItem(
          selected = currentTab == DashboardTab.TRANSACTIONS,
          onClick = { currentTab = DashboardTab.TRANSACTIONS },
          icon = {
            Icon(
              imageVector = if (currentTab == DashboardTab.TRANSACTIONS) Icons.AutoMirrored.Filled.ReceiptLong else Icons.AutoMirrored.Outlined.ReceiptLong,
              contentDescription = "Transactions"
            )
          },
          label = {
            Text(
              "History",
              fontSize = 11.sp,
              fontWeight = if (currentTab == DashboardTab.TRANSACTIONS) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = FintechPrimary,
            selectedTextColor = FintechPrimary,
            indicatorColor = FintechPrimary.copy(alpha = 0.12f)
          ),
          modifier = Modifier.testTag("nav_tab_transactions")
        )

        // Cards & Bank
        NavigationBarItem(
          selected = currentTab == DashboardTab.CARDS,
          onClick = { currentTab = DashboardTab.CARDS },
          icon = {
            Icon(
              imageVector = if (currentTab == DashboardTab.CARDS) Icons.Filled.CreditCard else Icons.Outlined.CreditCard,
              contentDescription = "Cards"
            )
          },
          label = {
            Text(
              "Cards",
              fontSize = 11.sp,
              fontWeight = if (currentTab == DashboardTab.CARDS) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = FintechPrimary,
            selectedTextColor = FintechPrimary,
            indicatorColor = FintechPrimary.copy(alpha = 0.12f)
          ),
          modifier = Modifier.testTag("nav_tab_cards")
        )

        // Profile
        NavigationBarItem(
          selected = currentTab == DashboardTab.PROFILE,
          onClick = { currentTab = DashboardTab.PROFILE },
          icon = {
            Icon(
              imageVector = if (currentTab == DashboardTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
              contentDescription = "Profile"
            )
          },
          label = {
            Text(
              "Profile",
              fontSize = 11.sp,
              fontWeight = if (currentTab == DashboardTab.PROFILE) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = FintechPrimary,
            selectedTextColor = FintechPrimary,
            indicatorColor = FintechPrimary.copy(alpha = 0.12f)
          ),
          modifier = Modifier.testTag("nav_tab_profile")
        )
      }
    },
    floatingActionButton = {
      if (currentTab == DashboardTab.HOME) {
        FloatingActionButton(
          onClick = onNavigateToScanPay,
          containerColor = FintechPrimary,
          contentColor = Color.White,
          shape = androidx.compose.foundation.shape.CircleShape,
          modifier = Modifier
            .size(56.dp)
            .testTag("home_scan_fab")
        ) {
          Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan & Pay")
        }
      }
    },
    modifier = modifier.testTag("dashboard_container_root")
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentTab) {
        DashboardTab.HOME -> {
          HomeScreen(
            uiState = uiState,
            onToggleBalanceVisibility = onToggleBalanceVisibility,
            onNavigateToSendMoney = onNavigateToSendMoney,
            onNavigateToAddMoney = onNavigateToAddMoney,
            onNavigateToScanPay = onNavigateToScanPay,
            onNavigateToTransactions = { currentTab = DashboardTab.TRANSACTIONS },
            onNavigateToCards = { currentTab = DashboardTab.CARDS },
            onNavigateToBank = { currentTab = DashboardTab.CARDS },
            onNavigateToSavingsVault = onNavigateToSavingsVault,
            onNavigateToSettings = onNavigateToSettings
          )
        }

        DashboardTab.TRANSACTIONS -> {
          TransactionHistoryScreen(
            uiState = uiState,
            onNavigateToSendMoney = onNavigateToSendMoney
          )
        }

        DashboardTab.CARDS -> {
          CardsBankScreen(
            uiState = uiState,
            onToggleCardFreeze = onToggleCardFreeze,
            onToggleCardOnline = onToggleCardOnline,
            onToggleCardInternational = onToggleCardInternational,
            onAddBankAccount = onAddBankAccount
          )
        }

        DashboardTab.PROFILE -> {
          ProfileScreen(
            uiState = uiState,
            onUpdateProfile = onUpdateProfile,
            onNavigateToSettings = onNavigateToSettings,
            onLogout = onLogout
          )
        }
      }
    }
  }
}
