package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechRose
import com.example.ui.theme.FintechSecondary
import com.example.viewmodel.AppUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
  uiState: AppUiState,
  onUpdateProfile: (name: String, phone: String, email: String) -> Unit,
  onNavigateToSettings: () -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier
) {
  val clipboardManager = LocalClipboardManager.current
  var showEditProfileDialog by remember { mutableStateOf(false) }
  var showLogoutConfirmDialog by remember { mutableStateOf(false) }
  var showRewardsDialog by remember { mutableStateOf(false) }
  var showHelpDialog by remember { mutableStateOf(false) }
  var showAboutDialog by remember { mutableStateOf(false) }
  var copiedToast by remember { mutableStateOf<String?>(null) }

  var editName by remember { mutableStateOf(uiState.user.name) }
  var editPhone by remember { mutableStateOf(uiState.user.phone) }
  var editEmail by remember { mutableStateOf(uiState.user.email) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("My Profile", fontWeight = FontWeight.Bold) },
        actions = {
          IconButton(onClick = onNavigateToSettings, modifier = Modifier.testTag("profile_settings_action")) {
            Icon(Icons.Default.Settings, contentDescription = "Settings")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("profile_screen_root")
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 20.dp),
      contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. User Header Card
      item {
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(
              modifier = Modifier
                .size(80.dp)
                .background(FintechPrimary, CircleShape)
                .border(3.dp, FintechSecondary, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = uiState.user.name.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = uiState.user.name,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(Icons.Default.Verified, contentDescription = "Verified", tint = FintechSecondary, modifier = Modifier.size(18.dp))
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = uiState.user.email,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = uiState.user.phone,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            // UPI ID Pill with copy
            Surface(
              shape = RoundedCornerShape(100.dp),
              color = FintechPrimary.copy(alpha = 0.08f),
              modifier = Modifier.clickable {
                clipboardManager.setText(AnnotatedString(uiState.user.upiId))
                copiedToast = "UPI ID copied!"
              }
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = uiState.user.upiId,
                  color = FintechPrimary,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = FintechPrimary, modifier = Modifier.size(14.dp))
              }
            }

            copiedToast?.let { toast ->
              Spacer(modifier = Modifier.height(4.dp))
              Text(toast, fontSize = 11.sp, color = FintechSecondary, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
              onClick = {
                editName = uiState.user.name
                editPhone = uiState.user.phone
                editEmail = uiState.user.email
                showEditProfileDialog = true
              },
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              modifier = Modifier.testTag("edit_profile_button")
            ) {
              Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Edit Profile Details", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }

      // 2. Account KYC & Financial Status
      item {
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text("KYC & Account Status", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(12.dp))

            ProfileMenuRow(
              icon = Icons.Default.Shield,
              title = "KYC Verification",
              subtitle = "Tier 3 Full Access • Unlimited Limits",
              badge = "VERIFIED",
              badgeColor = FintechSecondary,
              onClick = {}
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            ProfileMenuRow(
              icon = Icons.Default.Security,
              title = "Security & App Lock",
              subtitle = "Biometric & UPI PIN protection active",
              onClick = onNavigateToSettings
            )
          }
        }
      }

      // 3. Rewards & Preferences Section
      item {
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text("Perks & Preferences", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(12.dp))

            ProfileMenuRow(
              icon = Icons.Default.CardGiftcard,
              title = "Refer & Earn ₹100",
              subtitle = "Invite friends to Smart Saving Pay",
              badge = "NEW",
              badgeColor = Color(0xFFF59E0B),
              onClick = { showRewardsDialog = true }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            ProfileMenuRow(
              icon = Icons.Default.Settings,
              title = "App Settings",
              subtitle = "Theme, Notifications, Language",
              onClick = onNavigateToSettings
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            ProfileMenuRow(
              icon = Icons.Default.HelpOutline,
              title = "Help & Support",
              subtitle = "FAQs, 24/7 Chat & Ticket status",
              onClick = { showHelpDialog = true }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            ProfileMenuRow(
              icon = Icons.Default.Info,
              title = "About Smart Saving Pay",
              subtitle = "Version 1.0.0 • Architecture & Policies",
              onClick = { showAboutDialog = true }
            )
          }
        }
      }

      // 4. Logout Button
      item {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = FintechRose.copy(alpha = 0.1f),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { showLogoutConfirmDialog = true }
            .testTag("profile_logout_button")
        ) {
          Row(
            modifier = Modifier
              .padding(vertical = 14.dp)
              .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = FintechRose, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Log Out of Account",
              color = FintechRose,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }
    }
  }

  // Edit Profile Dialog
  if (showEditProfileDialog) {
    AlertDialog(
      onDismissRequest = { showEditProfileDialog = false },
      title = { Text("Edit Profile Details", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = editName,
            onValueChange = { editName = it },
            label = { Text("Full Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = editPhone,
            onValueChange = { editPhone = it },
            label = { Text("Mobile Number") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = editEmail,
            onValueChange = { editEmail = it },
            label = { Text("Email Address") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onUpdateProfile(editName, editPhone, editEmail)
            showEditProfileDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary)
        ) {
          Text("Save Changes")
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditProfileDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Logout Confirm Dialog
  if (showLogoutConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showLogoutConfirmDialog = false },
      title = { Text("Log Out?", fontWeight = FontWeight.Bold) },
      text = { Text("Are you sure you want to log out of Smart Saving Pay?") },
      confirmButton = {
        Button(
          onClick = {
            showLogoutConfirmDialog = false
            onLogout()
          },
          colors = ButtonDefaults.buttonColors(containerColor = FintechRose)
        ) {
          Text("Log Out")
        }
      },
      dismissButton = {
        TextButton(onClick = { showLogoutConfirmDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Rewards Dialog
  if (showRewardsDialog) {
    AlertDialog(
      onDismissRequest = { showRewardsDialog = false },
      title = { Text("Smart Referral Rewards 🎁", fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text("Invite your friends to try Smart Saving Pay! When they complete their first transaction or savings round-up, you both receive ₹100 in demo balance.", fontSize = 13.sp)
          Spacer(modifier = Modifier.height(10.dp))
          Text("Your Referral Code: SMARTSAVE2026", fontWeight = FontWeight.Bold, color = FintechPrimary)
        }
      },
      confirmButton = {
        Button(onClick = { showRewardsDialog = false }) {
          Text("Got it")
        }
      }
    )
  }

  // Help Dialog
  if (showHelpDialog) {
    AlertDialog(
      onDismissRequest = { showHelpDialog = false },
      title = { Text("Help & Support 💬", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("• How do Round-Up Savings work?", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          Text("Every time you pay with UPI, we round up the amount to the nearest 10 or 100 rupees and deposit the spare change in your 7.2% APY Vault.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text("• Is this real money?", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          Text("No, this is an interactive demo application showcasing production fintech architecture.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      },
      confirmButton = {
        Button(onClick = { showHelpDialog = false }) {
          Text("Close")
        }
      }
    )
  }

  // About Dialog
  if (showAboutDialog) {
    AlertDialog(
      onDismissRequest = { showAboutDialog = false },
      title = { Text("About Smart Saving Pay", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("Smart Saving Pay v1.0.0", fontWeight = FontWeight.Bold)
          Text("Built with Kotlin, Jetpack Compose, Material 3, and Clean Fintech Architecture.", fontSize = 13.sp)
          Text("Designed for automated micro-savings, virtual cards, and instant UPI payments.", fontSize = 13.sp)
        }
      },
      confirmButton = {
        Button(onClick = { showAboutDialog = false }) {
          Text("OK")
        }
      }
    )
  }
}

@Composable
fun ProfileMenuRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  badge: String? = null,
  badgeColor: Color = FintechPrimary,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .background(FintechPrimary.copy(alpha = 0.08f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = FintechPrimary, modifier = Modifier.size(20.dp))
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
          if (badge != null) {
            Spacer(modifier = Modifier.width(6.dp))
            Surface(shape = RoundedCornerShape(6.dp), color = badgeColor.copy(alpha = 0.2f)) {
              Text(badge, color = badgeColor, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
          }
        }
        Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
  }
}
