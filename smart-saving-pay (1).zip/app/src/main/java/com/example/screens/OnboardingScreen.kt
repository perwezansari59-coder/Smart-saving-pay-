package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary
import kotlinx.coroutines.launch

data class OnboardingPage(
  val title: String,
  val subtitle: String,
  val description: String,
  val icon: ImageVector,
  val color: Color
)

@Composable
fun OnboardingScreen(
  onGetStarted: () -> Unit,
  onLoginClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val pages = listOf(
    OnboardingPage(
      title = "Smart Auto-Savings",
      subtitle = "Save every time you spend",
      description = "Automate your savings with intelligent round-ups. Every UPI payment saves your spare change into a 7.2% APY demo vault.",
      icon = Icons.Default.Savings,
      color = FintechSecondary
    ),
    OnboardingPage(
      title = "Instant UPI & QR Pay",
      subtitle = "Lightning-fast money transfers",
      description = "Scan any QR code or send money to contacts instantly. Experience effortless payments with real-time receipt generation.",
      icon = Icons.Default.QrCodeScanner,
      color = FintechPrimary
    ),
    OnboardingPage(
      title = "Virtual Cards & Safety",
      subtitle = "Full control in your pocket",
      description = "Generate sleek RuPay and Visa virtual cards with instant freeze protection, customizable limits, and zero liability.",
      icon = Icons.Default.CreditCard,
      color = Color(0xFF6366F1)
    )
  )

  val pagerState = rememberPagerState(pageCount = { pages.size })
  val coroutineScope = rememberCoroutineScope()

  Surface(
    modifier = modifier
      .fillMaxSize()
      .testTag("onboarding_screen_root"),
    color = MaterialTheme.colorScheme.background
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp, vertical = 20.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top row: Skip button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        if (pagerState.currentPage < pages.size - 1) {
          TextButton(
            onClick = onGetStarted,
            modifier = Modifier.testTag("onboarding_skip_button")
          ) {
            Text(
              text = "Skip",
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontWeight = FontWeight.SemiBold,
              fontSize = 15.sp
            )
          }
        } else {
          Spacer(modifier = Modifier.height(48.dp))
        }
      }

      // Pager Content
      HorizontalPager(
        state = pagerState,
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
      ) { pageIndex ->
        val page = pages[pageIndex]
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center,
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
        ) {
          // Circular Icon Container with ambient glow
          Box(
            modifier = Modifier
              .size(160.dp)
              .background(page.color.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Box(
              modifier = Modifier
                .size(110.dp)
                .background(page.color.copy(alpha = 0.25f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = page.icon,
                contentDescription = null,
                tint = page.color,
                modifier = Modifier.size(54.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(36.dp))

          Text(
            text = page.title,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = page.subtitle,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = page.color,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = page.description,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
          )
        }
      }

      // Bottom Section: Indicators and Action Buttons
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Dot Indicators
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(bottom = 28.dp)
        ) {
          repeat(pages.size) { index ->
            val isSelected = pagerState.currentPage == index
            Box(
              modifier = Modifier
                .height(8.dp)
                .width(if (isSelected) 24.dp else 8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(
                  if (isSelected) FintechPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            )
          }
        }

        // Main Action Button
        Button(
          onClick = {
            if (pagerState.currentPage < pages.size - 1) {
              coroutineScope.launch {
                pagerState.animateScrollToPage(pagerState.currentPage + 1)
              }
            } else {
              onGetStarted()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("onboarding_primary_button")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Text(
              text = if (pagerState.currentPage == pages.size - 1) "Get Started" else "Continue",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = null,
              modifier = Modifier.size(18.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Sign In option
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Already have an account? ",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp
          )
          TextButton(
            onClick = onLoginClick,
            modifier = Modifier.testTag("onboarding_login_text_button")
          ) {
            Text(
              text = "Log In",
              color = FintechPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }
    }
  }
}
