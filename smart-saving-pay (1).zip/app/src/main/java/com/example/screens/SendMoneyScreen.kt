package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RecentPayee
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechRose
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils
import com.example.viewmodel.AppUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SendMoneyScreen(
  uiState: AppUiState,
  initialPayee: String = "",
  initialUpi: String = "",
  initialAmount: String = "",
  onNavigateToUpiPin: (payee: String, upi: String, amount: String, note: String) -> Unit,
  onNavigateToScanQr: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  var recipientName by remember { mutableStateOf(initialPayee) }
  var upiId by remember { mutableStateOf(initialUpi) }
  var amountText by remember { mutableStateOf(initialAmount) }
  var noteText by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val quickAmounts = listOf("100", "500", "1000", "2000", "5000")

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Send Money", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("send_money_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        actions = {
          IconButton(onClick = onNavigateToScanQr, modifier = Modifier.testTag("send_money_scan_qr_action")) {
            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan QR")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("send_money_screen_root")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 24.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.Top
    ) {
      Spacer(modifier = Modifier.height(8.dp))

      // Recent Contacts Horizontal Picker
      Text(
        text = "Quick Contacts",
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(10.dp))

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(uiState.recentPayees) { payee ->
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
              .clickable {
                recipientName = payee.name
                upiId = payee.upiId
                errorMessage = null
              }
              .testTag("send_quick_payee_${payee.name.replace(" ", "_")}")
          ) {
            Box(
              modifier = Modifier
                .size(50.dp)
                .background(Color(payee.avatarColor), CircleShape)
                .border(
                  width = if (recipientName == payee.name) 2.dp else 0.dp,
                  color = if (recipientName == payee.name) FintechPrimary else Color.Transparent,
                  shape = CircleShape
                ),
              contentAlignment = Alignment.Center
            ) {
              Text(payee.avatarInitials, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = payee.name.split(" ").firstOrNull() ?: payee.name,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Recipient Name
      OutlinedTextField(
        value = recipientName,
        onValueChange = { recipientName = it; errorMessage = null },
        label = { Text("Recipient Name") },
        placeholder = { Text("e.g. Rahul Sharma") },
        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
        shape = RoundedCornerShape(14.dp),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("send_recipient_name_input")
      )

      Spacer(modifier = Modifier.height(12.dp))

      // UPI ID or Mobile Number
      OutlinedTextField(
        value = upiId,
        onValueChange = { upiId = it; errorMessage = null },
        label = { Text("Mobile Number or UPI ID") },
        placeholder = { Text("e.g. rahul@oksbi or 9823111223") },
        shape = RoundedCornerShape(14.dp),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("send_upi_id_input")
      )

      Spacer(modifier = Modifier.height(20.dp))

      // Amount Input Card
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Enter Amount", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "₹",
              fontSize = 32.sp,
              fontWeight = FontWeight.Bold,
              color = FintechPrimary
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
              value = amountText,
              onValueChange = {
                if (it.all { c -> c.isDigit() || c == '.' }) {
                  amountText = it
                  errorMessage = null
                }
              },
              placeholder = { Text("0", fontSize = 30.sp, color = MaterialTheme.colorScheme.outline) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              shape = RoundedCornerShape(12.dp),
              singleLine = true,
              textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              ),
              modifier = Modifier
                .weight(1f)
                .testTag("send_amount_input")
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Quick Amount Chips
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            items(quickAmounts) { chipAmount ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (amountText == chipAmount) FintechPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .clickable {
                    amountText = chipAmount
                    errorMessage = null
                  }
                  .testTag("quick_amount_$chipAmount")
              ) {
                Text(
                  text = "+₹$chipAmount",
                  color = if (amountText == chipAmount) Color.White else MaterialTheme.colorScheme.onSurface,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Note Field
      OutlinedTextField(
        value = noteText,
        onValueChange = { noteText = it },
        label = { Text("Add a note (optional)") },
        placeholder = { Text("e.g. Dinner, Rent, Tickets") },
        shape = RoundedCornerShape(14.dp),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("send_note_input")
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Paying From Account Selector Card
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountBalance, contentDescription = null, tint = FintechPrimary, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("Paying from", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text("Smart Savings Bank •••• 8219", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
          }

          Text(
            text = "Bal: ${FintechUtils.formatCurrency(uiState.totalBalance)}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = FintechSecondary
          )
        }
      }

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = errorMessage!!,
          color = FintechRose,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Continue to UPI PIN Button
      Button(
        onClick = {
          if (recipientName.isBlank() && upiId.isBlank()) {
            errorMessage = "Please enter recipient name or UPI ID"
            return@Button
          }
          val amount = amountText.toDoubleOrNull()
          if (amount == null || amount <= 0.0) {
            errorMessage = "Please enter a valid transfer amount"
            return@Button
          }
          if (amount > uiState.totalBalance) {
            errorMessage = "Insufficient demo balance (${FintechUtils.formatCurrency(uiState.totalBalance)})"
            return@Button
          }

          val payee = recipientName.ifBlank { upiId }
          val upi = upiId.ifBlank { "${recipientName.lowercase().replace(" ", "")}@upi" }
          onNavigateToUpiPin(payee, upi, amountText, noteText)
        },
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("send_money_proceed_button")
      ) {
        Text("Proceed to UPI PIN", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
