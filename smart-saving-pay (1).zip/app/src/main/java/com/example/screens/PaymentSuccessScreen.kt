package com.example.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.DetailRow
import com.example.model.Transaction
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils
import com.example.viewmodel.AppUiState

@Composable
fun PaymentSuccessScreen(
  txnId: String,
  uiState: AppUiState,
  onDone: () -> Unit,
  onViewTransaction: (Transaction) -> Unit,
  modifier: Modifier = Modifier
) {
  val clipboardManager = LocalClipboardManager.current
  var copiedNotice by remember { mutableStateOf<String?>(null) }
  val scale = remember { Animatable(0.4f) }

  LaunchedEffect(Unit) {
    scale.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
    )
  }

  val txn = uiState.transactions.find { it.id == txnId } ?: uiState.lastTransaction ?: uiState.transactions.firstOrNull()

  Surface(
    modifier = modifier
      .fillMaxSize()
      .testTag("payment_success_screen_root"),
    color = MaterialTheme.colorScheme.background
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp, vertical = 28.dp)
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(20.dp))

        // Success Checkmark Animation Box
        Box(
          modifier = Modifier
            .size(90.dp)
            .scale(scale.value)
            .background(Color(0xFFECFDF5), CircleShape)
            .border(3.dp, FintechSecondary, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Success",
            tint = FintechSecondary,
            modifier = Modifier.size(48.dp)
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
          text = "Payment Successful!",
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold,
          color = FintechSecondary
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "Paid to ${txn?.recipientOrSender ?: "Recipient"}",
          fontSize = 15.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = FintechUtils.formatCurrency(txn?.amount ?: 0.0),
          fontSize = 36.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Smart Savings Bonus Pill if enabled
        if (uiState.roundUpSavingsEnabled) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = FintechSecondary.copy(alpha = 0.12f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(32.dp)
                  .background(FintechSecondary.copy(alpha = 0.25f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Savings, contentDescription = null, tint = FintechSecondary, modifier = Modifier.size(18.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "Smart Auto-Roundup Applied",
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = FintechSecondary
                )
                Text(
                  text = "Spare change automatically saved to your Vault",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(16.dp))
        }

        // Receipt Details Card
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            DetailRow(label = "Transaction ID", value = txn?.id ?: "TXN82910481", isCopyable = true, onCopy = {
              clipboardManager.setText(AnnotatedString(txn?.id ?: ""))
              copiedNotice = "Txn ID copied to clipboard!"
            })
            DetailRow(label = "UPI Reference No", value = txn?.referenceId ?: "UPI/9182371920", isCopyable = true, onCopy = {
              clipboardManager.setText(AnnotatedString(txn?.referenceId ?: ""))
              copiedNotice = "UPI Ref copied to clipboard!"
            })
            DetailRow(label = "Paid via", value = "Smart Saving Pay Wallet")
            DetailRow(label = "Date & Time", value = FintechUtils.formatDate(txn?.timestamp ?: System.currentTimeMillis()))
            if (!txn?.note.isNullOrBlank()) {
              DetailRow(label = "Note", value = txn!!.note)
            }
          }
        }

        if (copiedNotice != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = copiedNotice!!,
            color = FintechSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      // Bottom Action Buttons
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = onDone,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("payment_success_done_button")
        ) {
          Text("Done", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = {
            if (txn != null) {
              onViewTransaction(txn)
            } else {
              onDone()
            }
          },
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("payment_success_view_details_button")
        ) {
          Text("View in History", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}
