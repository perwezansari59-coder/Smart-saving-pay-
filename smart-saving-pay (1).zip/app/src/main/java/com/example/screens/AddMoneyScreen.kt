package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechRose
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils
import com.example.viewmodel.AppUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMoneyScreen(
  uiState: AppUiState,
  onAddMoneyConfirmed: (amount: Double, sourceName: String) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  var amountText by remember { mutableStateOf("1000") }
  var selectedSourceIndex by remember { mutableStateOf(0) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var successMessage by remember { mutableStateOf<String?>(null) }

  val quickAmounts = listOf("500", "1000", "2000", "5000", "10000")

  val sources = listOf(
    "Smart Savings Bank (•••• 8219)",
    "HDFC Bank (•••• 4390)",
    "RuPay Debit Card (•••• 9182)",
    "Net Banking (Instant Approval)"
  )

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Add Money to Wallet", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("add_money_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("add_money_screen_root")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 24.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.Top
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      // Current balance chip
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Current Wallet Balance", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = FintechUtils.formatCurrency(uiState.totalBalance),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = FintechSecondary
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Amount Input Card
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text("Deposit Amount", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("₹", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = FintechPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
              value = amountText,
              onValueChange = {
                if (it.all { c -> c.isDigit() || c == '.' }) {
                  amountText = it
                  errorMessage = null
                  successMessage = null
                }
              },
              placeholder = { Text("0", fontSize = 30.sp) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              shape = RoundedCornerShape(14.dp),
              singleLine = true,
              textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              ),
              modifier = Modifier
                .weight(1f)
                .testTag("add_money_amount_input")
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            items(quickAmounts) { chipAmount ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (amountText == chipAmount) FintechPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .clickable {
                    amountText = chipAmount
                    errorMessage = null
                    successMessage = null
                  }
                  .testTag("add_quick_chip_$chipAmount")
              ) {
                Text(
                  text = "+₹$chipAmount",
                  color = if (amountText == chipAmount) Color.White else MaterialTheme.colorScheme.onSurface,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      Text("Select Payment Source", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
      Spacer(modifier = Modifier.height(10.dp))

      // Sources List
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        sources.forEachIndexed { index, source ->
          val isSelected = selectedSourceIndex == index
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(
              width = if (isSelected) 2.dp else 1.dp,
              color = if (isSelected) FintechPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
            ),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { selectedSourceIndex = index }
              .testTag("payment_source_$index")
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (source.contains("Card")) Icons.Default.CreditCard else Icons.Default.AccountBalance,
                  contentDescription = null,
                  tint = if (isSelected) FintechPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = source,
                  fontSize = 13.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
              }

              Icon(
                imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isSelected) FintechPrimary else MaterialTheme.colorScheme.outline
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Demo disclaimer
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = FintechPrimary.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Info, contentDescription = null, tint = FintechPrimary, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Demo Simulation: Balance will be credited immediately to your local prototype account.",
            fontSize = 11.sp,
            color = FintechPrimary,
            lineHeight = 15.sp
          )
        }
      }

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(10.dp))
        Text(errorMessage!!, color = FintechRose, fontSize = 13.sp, fontWeight = FontWeight.Medium)
      }

      if (successMessage != null) {
        Spacer(modifier = Modifier.height(10.dp))
        Text(successMessage!!, color = FintechSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Add Money Button
      Button(
        onClick = {
          val amt = amountText.toDoubleOrNull()
          if (amt == null || amt <= 0.0) {
            errorMessage = "Please enter a valid deposit amount"
            return@Button
          }
          val source = sources[selectedSourceIndex]
          onAddMoneyConfirmed(amt, source)
          successMessage = "Successfully deposited ${FintechUtils.formatCurrency(amt)} via $source!"
        },
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("confirm_add_money_button")
      ) {
        Text("Add Money Instantly", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
