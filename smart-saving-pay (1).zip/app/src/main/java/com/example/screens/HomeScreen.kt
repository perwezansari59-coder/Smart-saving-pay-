package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.BalanceCard
import com.example.components.QuickActionGrid
import com.example.components.TransactionDetailSheet
import com.example.components.TransactionItemCard
import com.example.model.RecentPayee
import com.example.model.Transaction
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils
import com.example.viewmodel.AppUiState

@Composable
fun HomeScreen(
  uiState: AppUiState,
  onToggleBalanceVisibility: () -> Unit,
  onNavigateToSendMoney: (payee: String, upi: String, amount: String) -> Unit,
  onNavigateToAddMoney: () -> Unit,
  onNavigateToScanPay: () -> Unit,
  onNavigateToTransactions: () -> Unit,
  onNavigateToCards: () -> Unit,
  onNavigateToBank: () -> Unit,
  onNavigateToSavingsVault: () -> Unit,
  onNavigateToSettings: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTransaction by remember { mutableStateOf<Transaction?>(null) }
  var showNotificationsDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("home_screen_root"),
    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 28.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp)
  ) {
    // 1. Top Header: User Profile Greeting & Action Icons
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.testTag("home_profile_header")
        ) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .background(FintechPrimary, CircleShape)
              .border(2.dp, FintechSecondary, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = uiState.user.name.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Hello, ${uiState.user.name.split(" ").firstOrNull() ?: "Alex"}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = "KYC Verified",
                tint = FintechSecondary,
                modifier = Modifier.size(16.dp)
              )
            }
            Text(
              text = uiState.user.upiId,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onNavigateToScanPay,
            modifier = Modifier.testTag("home_scan_qr_button")
          ) {
            Icon(
              imageVector = Icons.Default.QrCodeScanner,
              contentDescription = "Scan QR",
              tint = MaterialTheme.colorScheme.onSurface
            )
          }

          IconButton(
            onClick = { showNotificationsDialog = true },
            modifier = Modifier.testTag("home_notifications_button")
          ) {
            BadgedBox(
              badge = {
                Badge(
                  containerColor = FintechSecondary,
                  modifier = Modifier.size(8.dp)
                )
              }
            ) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notifications",
                tint = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }

    // 2. Balance Hero Card
    item {
      BalanceCard(
        totalBalance = uiState.totalBalance,
        savingsBalance = uiState.savingsBalance,
        isBalanceVisible = uiState.isBalanceVisible,
        onToggleVisibility = onToggleBalanceVisibility,
        onSendMoney = { onNavigateToSendMoney("", "", "") },
        onAddMoney = onNavigateToAddMoney,
        onOpenSavingsVault = onNavigateToSavingsVault
      )
    }

    // 3. Quick Actions Grid
    item {
      QuickActionGrid(
        onSendMoney = { onNavigateToSendMoney("", "", "") },
        onScanPay = onNavigateToScanPay,
        onAddMoney = onNavigateToAddMoney,
        onTransactions = onNavigateToTransactions,
        onCards = onNavigateToCards,
        onBankTransfer = onNavigateToBank
      )
    }

    // 4. Quick Payees Row (Avatars)
    item {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Send to Friends",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onBackground
          )
          TextButton(onClick = { onNavigateToSendMoney("", "", "") }) {
            Text("See All", color = FintechPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(14.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          // Add new contact button
          item {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.clickable { onNavigateToSendMoney("", "", "") }
            ) {
              Box(
                modifier = Modifier
                  .size(54.dp)
                  .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                  .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = "Add Payee",
                  tint = MaterialTheme.colorScheme.onSurface
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text("New Payee", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }

          items(uiState.recentPayees) { payee ->
            QuickPayeeAvatar(
              payee = payee,
              onClick = {
                onNavigateToSendMoney(payee.name, payee.upiId, "")
              }
            )
          }
        }
      }
    }

    // 5. Smart Savings & Round-up Summary Card
    item {
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onNavigateToSavingsVault)
          .testTag("home_savings_summary_card")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(FintechSecondary.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Savings, contentDescription = null, tint = FintechSecondary, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("Smart Round-Up Savings", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Auto-saved on payments", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = FintechSecondary.copy(alpha = 0.12f)
            ) {
              Text(
                text = "ACTIVE",
                color = FintechSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Emergency Goal", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("₹38,500 / ₹50,000 (77%)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = FintechSecondary)
          }

          Spacer(modifier = Modifier.height(6.dp))

          LinearProgressIndicator(
            progress = { 0.77f },
            color = FintechSecondary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp))
          )
        }
      }
    }

    // 6. Recent Transactions List
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Recent Transactions",
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp,
          color = MaterialTheme.colorScheme.onBackground
        )
        TextButton(onClick = onNavigateToTransactions) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("View All", color = FintechPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = FintechPrimary, modifier = Modifier.size(14.dp))
          }
        }
      }
    }

    items(uiState.transactions.take(4)) { transaction ->
      TransactionItemCard(
        transaction = transaction,
        onClick = { selectedTransaction = transaction }
      )
    }
  }

  // Detail Sheet
  TransactionDetailSheet(
    transaction = selectedTransaction,
    onDismiss = { selectedTransaction = null },
    onRepeatPayment = { txn ->
      onNavigateToSendMoney(txn.recipientOrSender, txn.upiId, txn.amount.toString())
    }
  )

  // Notifications Dialog
  if (showNotificationsDialog) {
    androidx.compose.material3.AlertDialog(
      onDismissRequest = { showNotificationsDialog = false },
      title = { Text("Notifications", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("• Interest of ₹110.40 credited to your Smart Savings Vault.", fontSize = 13.sp)
          Text("• Auto round-up enabled: ₹80 saved on Reliance Fresh payment.", fontSize = 13.sp)
          Text("• RuPay Virtual Card limit reset for the new billing cycle.", fontSize = 13.sp)
        }
      },
      confirmButton = {
        TextButton(onClick = { showNotificationsDialog = false }) {
          Text("Dismiss")
        }
      }
    )
  }
}

@Composable
fun QuickPayeeAvatar(
  payee: RecentPayee,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .testTag("payee_${payee.name.replace(" ", "_")}")
  ) {
    Box(
      modifier = Modifier
        .size(54.dp)
        .background(Color(payee.avatarColor), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = payee.avatarInitials,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
      )
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = payee.name.split(" ").firstOrNull() ?: payee.name,
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium,
      color = MaterialTheme.colorScheme.onSurface
    )
  }
}
