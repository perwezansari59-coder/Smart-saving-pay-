package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FintechGold
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechRose
import com.example.ui.theme.FintechSecondary
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OtpScreen(
  phone: String,
  onVerifySuccess: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  var otpCode by remember { mutableStateOf("") }
  var countdown by remember { mutableIntStateOf(30) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var resendNotice by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(countdown) {
    if (countdown > 0) {
      delay(1000)
      countdown -= 1
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Verification", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("otp_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("otp_screen_root")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(16.dp))

      Box(
        modifier = Modifier
          .size(72.dp)
          .background(FintechSecondary.copy(alpha = 0.12f), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Security,
          contentDescription = null,
          tint = FintechSecondary,
          modifier = Modifier.size(36.dp)
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Text(
        text = "Enter 6-Digit Code",
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "A simulated demo OTP code was generated for ${if (phone.isNotBlank()) phone else "+91 98765 43210"}",
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        lineHeight = 18.sp
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Demo OTP Indicator Card
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = FintechPrimary.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(Icons.Default.Info, contentDescription = null, tint = FintechPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("DEMO OTP: 123456", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FintechPrimary)
              Text("No real SMS is sent to any carrier", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }

          OutlinedButton(
            onClick = {
              otpCode = "123456"
              errorMessage = null
            },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("otp_autofill_button")
          ) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = FintechGold, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Fill", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      // 6 Digit Individual Boxes using hidden BasicTextField
      BasicTextField(
        value = otpCode,
        onValueChange = {
          if (it.length <= 6 && it.all { char -> char.isDigit() }) {
            otpCode = it
            errorMessage = null
          }
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        decorationBox = {
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.testTag("otp_digit_boxes_row")
          ) {
            for (i in 0 until 6) {
              val char = if (i < otpCode.length) otpCode[i].toString() else ""
              val isCurrent = i == otpCode.length

              Box(
                modifier = Modifier
                  .size(48.dp)
                  .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                  .border(
                    width = if (isCurrent) 2.dp else 1.dp,
                    color = if (isCurrent) FintechPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(12.dp)
                  ),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = char,
                  fontSize = 20.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        },
        modifier = Modifier.testTag("otp_text_input")
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = errorMessage!!,
          color = FintechRose,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )
      }

      if (resendNotice != null) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = resendNotice!!,
          color = FintechSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium
        )
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Verify Button
      Button(
        onClick = {
          if (otpCode.length == 6) {
            onVerifySuccess()
          } else {
            errorMessage = "Please enter the 6-digit demo OTP (123456)"
          }
        },
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = FintechPrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("otp_verify_button")
      ) {
        Text("Verify & Continue", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Resend Timer Row
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        if (countdown > 0) {
          Text(
            text = "Resend OTP in ${countdown}s",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp
          )
        } else {
          TextButton(
            onClick = {
              countdown = 30
              resendNotice = "Demo OTP 123456 refreshed!"
            },
            modifier = Modifier.testTag("otp_resend_button")
          ) {
            Text(
              text = "Resend Code",
              color = FintechPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }
    }
  }
}
