package com.example.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.NumericKeypad
import com.example.components.PinDotsDisplay
import com.example.model.Transaction
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpiPinScreen(
  payee: String,
  upi: String,
  amount: String,
  note: String,
  onPaymentConfirmed: (payee: String, upi: String, amount: Double, note: String) -> Transaction,
  onNavigateToSuccess: (txnId: String) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  var enteredPin by remember { mutableStateOf("") }
  var isProcessing by remember { mutableStateOf(false) }
  val coroutineScope = rememberCoroutineScope()

  val amountDouble = amount.toDoubleOrNull() ?: 0.0

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Enter UPI PIN", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack, enabled = !isProcessing, modifier = Modifier.testTag("upi_pin_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    modifier = modifier.testTag("upi_pin_screen_root")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top Transaction Context Card
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(8.dp))

        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "Paying to",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = payee,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            if (upi.isNotBlank()) {
              Text(
                text = upi,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = FintechUtils.formatCurrency(amountDouble),
              fontSize = 32.sp,
              fontWeight = FontWeight.Bold,
              color = FintechPrimary
            )

            Text(
              text = "From Smart Savings Bank •••• 8219",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Demo Disclaimer Pill
        Surface(
          shape = RoundedCornerShape(100.dp),
          color = FintechSecondary.copy(alpha = 0.12f)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Shield, contentDescription = null, tint = FintechSecondary, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "DEMO UPI PIN: Enter any 4-6 digits (e.g. 1234)",
              color = FintechSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (isProcessing) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 20.dp)
          ) {
            CircularProgressIndicator(
              color = FintechPrimary,
              strokeWidth = 3.dp,
              modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "Processing simulated UPI payment...",
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        } else {
          // PIN Dots
          PinDotsDisplay(
            pinLength = 4,
            currentLength = enteredPin.length,
            modifier = Modifier.testTag("upi_pin_dots_display")
          )
        }
      }

      // Numeric Keypad
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 24.dp)
      ) {
        if (!isProcessing) {
          NumericKeypad(
            onDigitClick = { digit ->
              if (enteredPin.length < 4) {
                enteredPin += digit
                if (enteredPin.length == 4) {
                  // Auto-submit on 4th digit
                  coroutineScope.launch {
                    isProcessing = true
                    delay(1000)
                    val txn = onPaymentConfirmed(payee, upi, amountDouble, note)
                    onNavigateToSuccess(txn.id)
                  }
                }
              }
            },
            onBackspaceClick = {
              if (enteredPin.isNotEmpty()) {
                enteredPin = enteredPin.dropLast(1)
              }
            },
            onSubmitClick = {
              if (enteredPin.isNotEmpty()) {
                coroutineScope.launch {
                  isProcessing = true
                  delay(1000)
                  val txn = onPaymentConfirmed(payee, upi, amountDouble, note)
                  onNavigateToSuccess(txn.id)
                }
              }
            },
            isSubmitEnabled = enteredPin.isNotEmpty(),
            modifier = Modifier.testTag("upi_numeric_keypad")
          )
        }
      }
    }
  }
}
