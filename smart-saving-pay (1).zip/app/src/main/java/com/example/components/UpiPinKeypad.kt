package com.example.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary

@Composable
fun PinDotsDisplay(
  pinLength: Int,
  currentLength: Int,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.spacedBy(16.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    for (i in 0 until pinLength) {
      val isFilled = i < currentLength
      val dotColor by animateColorAsState(
        targetValue = if (isFilled) FintechPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
        label = "dot_color"
      )

      Box(
        modifier = Modifier
          .size(18.dp)
          .border(
            width = 2.dp,
            color = if (isFilled) FintechPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
            shape = CircleShape
          )
          .background(dotColor, CircleShape)
      )
    }
  }
}

@Composable
fun NumericKeypad(
  onDigitClick: (String) -> Unit,
  onBackspaceClick: () -> Unit,
  onSubmitClick: () -> Unit,
  isSubmitEnabled: Boolean,
  modifier: Modifier = Modifier
) {
  val rows = listOf(
    listOf("1", "2", "3"),
    listOf("4", "5", "6"),
    listOf("7", "8", "9"),
    listOf("backspace", "0", "submit")
  )

  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    for (row in rows) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
      ) {
        for (item in row) {
          when (item) {
            "backspace" -> {
              KeypadButton(
                onClick = onBackspaceClick,
                tag = "keypad_backspace"
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Backspace,
                  contentDescription = "Backspace",
                  tint = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.size(24.dp)
                )
              }
            }
            "submit" -> {
              KeypadButton(
                onClick = onSubmitClick,
                enabled = isSubmitEnabled,
                containerColor = if (isSubmitEnabled) FintechSecondary else MaterialTheme.colorScheme.surfaceVariant,
                tag = "keypad_submit"
              ) {
                Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = "Confirm PIN",
                  tint = if (isSubmitEnabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(26.dp)
                )
              }
            }
            else -> {
              KeypadButton(
                onClick = { onDigitClick(item) },
                tag = "keypad_$item"
              ) {
                Text(
                  text = item,
                  fontSize = 24.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun KeypadButton(
  onClick: () -> Unit,
  enabled: Boolean = true,
  containerColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
  tag: String,
  content: @Composable () -> Unit
) {
  Surface(
    shape = CircleShape,
    color = containerColor,
    modifier = Modifier
      .size(72.dp)
      .clip(CircleShape)
      .clickable(enabled = enabled, onClick = onClick)
      .testTag(tag)
  ) {
    Box(
      contentAlignment = Alignment.Center
    ) {
      content()
    }
  }
}
