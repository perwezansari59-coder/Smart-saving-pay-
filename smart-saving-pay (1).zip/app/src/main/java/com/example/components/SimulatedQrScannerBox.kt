package com.example.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechSecondary

data class PresetQrMerchant(
  val name: String,
  val upiId: String,
  val defaultAmount: String,
  val icon: String
)

@Composable
fun SimulatedQrScannerBox(
  onQrScanned: (name: String, upiId: String, amount: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var isFlashlightOn by remember { mutableStateOf(false) }

  val infiniteTransition = rememberInfiniteTransition(label = "scanner_laser")
  val scanPosition by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(2200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "laser_pos"
  )

  val presetMerchants = listOf(
    PresetQrMerchant("Cafe Coffee Day", "ccd.store90@icici", "220", "☕"),
    PresetQrMerchant("Reliance Fresh", "reliance.fresh@kotak", "650", "🛒"),
    PresetQrMerchant("Metro Express", "mumbai.metro@sbi", "45", "🚇"),
    PresetQrMerchant("BookWorld Store", "bookworld@hdfc", "380", "📚")
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(if (isFlashlightOn) Color(0xFF1E293B) else Color(0xFF0F172A)),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(24.dp))

    // Torch & Gallery Controls
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 32.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = CircleShape,
        color = if (isFlashlightOn) Color.Yellow.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.15f),
        modifier = Modifier.clickable { isFlashlightOn = !isFlashlightOn }
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = if (isFlashlightOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
            contentDescription = "Flashlight",
            tint = if (isFlashlightOn) Color.Yellow else Color.White,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isFlashlightOn) "Torch ON" else "Torch OFF",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      Surface(
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.15f),
        modifier = Modifier.clickable {
          // Simulate selecting from photo gallery
          val selected = presetMerchants.random()
          onQrScanned(selected.name, selected.upiId, selected.defaultAmount)
        }
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Image,
            contentDescription = "Gallery",
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text("Scan Image", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
      }
    }

    Spacer(modifier = Modifier.height(32.dp))

    // Viewfinder Target Frame
    Box(
      modifier = Modifier
        .size(270.dp)
        .testTag("qr_scanner_frame"),
      contentAlignment = Alignment.Center
    ) {
      // Corner brackets
      ScannerCornerBrackets(modifier = Modifier.fillMaxSize())

      // Center translucent simulation area
      Box(
        modifier = Modifier
          .size(240.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(Color.Black.copy(alpha = 0.3f)),
        contentAlignment = Alignment.Center
      ) {
        // Subtle QR placeholder in center
        Icon(
          imageVector = Icons.Default.QrCode,
          contentDescription = null,
          tint = Color.White.copy(alpha = 0.12f),
          modifier = Modifier.size(140.dp)
        )

        // Animated laser sweep line
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(3.dp)
            .align(Alignment.TopCenter)
            .offset(y = (237 * scanPosition).dp)
            .background(
              Brush.horizontalGradient(
                listOf(
                  Color.Transparent,
                  FintechSecondary,
                  Color.White,
                  FintechSecondary,
                  Color.Transparent
                )
              )
            )
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Align QR code within the frame to pay",
      color = Color.White.copy(alpha = 0.85f),
      fontSize = 14.sp,
      fontWeight = FontWeight.Medium
    )

    Text(
      text = "Smart Saving Pay • Instant UPI Verified",
      color = FintechSecondary,
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(28.dp))

    // Preset / Demo quick scan chips
    Text(
      text = "OR TAP A DEMO MERCHANT QR:",
      color = Color.White.copy(alpha = 0.6f),
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 1.sp
    )

    Spacer(modifier = Modifier.height(12.dp))

    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      for (merchant in presetMerchants) {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = Color.White.copy(alpha = 0.1f),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              onQrScanned(merchant.name, merchant.upiId, merchant.defaultAmount)
            }
            .testTag("scan_merchant_${merchant.name.replace(" ", "_")}")
        ) {
          Row(
            modifier = Modifier
              .padding(horizontal = 14.dp, vertical = 10.dp)
              .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = merchant.icon, fontSize = 20.sp)
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = merchant.name,
                  color = Color.White,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 13.sp
                )
                Text(
                  text = merchant.upiId,
                  color = Color.White.copy(alpha = 0.6f),
                  fontSize = 11.sp
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = FintechSecondary.copy(alpha = 0.25f)
            ) {
              Text(
                text = "Simulate Scan",
                color = FintechSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ScannerCornerBrackets(modifier: Modifier = Modifier) {
  val strokeColor = FintechSecondary
  val strokeWidth = 5.dp
  val cornerLength = 32.dp

  Canvas(modifier = modifier) {
    val sw = strokeWidth.toPx()
    val cl = cornerLength.toPx()
    val w = size.width
    val h = size.height

    // Top-Left
    drawLine(strokeColor, Offset(0f, 0f), Offset(cl, 0f), sw)
    drawLine(strokeColor, Offset(0f, 0f), Offset(0f, cl), sw)

    // Top-Right
    drawLine(strokeColor, Offset(w, 0f), Offset(w - cl, 0f), sw)
    drawLine(strokeColor, Offset(w, 0f), Offset(w, cl), sw)

    // Bottom-Left
    drawLine(strokeColor, Offset(0f, h), Offset(cl, h), sw)
    drawLine(strokeColor, Offset(0f, h), Offset(0f, h - cl), sw)

    // Bottom-Right
    drawLine(strokeColor, Offset(w, h), Offset(w - cl, h), sw)
    drawLine(strokeColor, Offset(w, h), Offset(w, h - cl), sw)
  }
}
