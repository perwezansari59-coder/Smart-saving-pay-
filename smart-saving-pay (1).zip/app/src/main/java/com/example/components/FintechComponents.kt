package com.example.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Transaction
import com.example.model.TransactionCategory
import com.example.model.TransactionStatus
import com.example.model.TransactionType
import com.example.model.VirtualCard
import com.example.ui.theme.FintechNavy
import com.example.ui.theme.FintechPrimary
import com.example.ui.theme.FintechRose
import com.example.ui.theme.FintechSecondary
import com.example.utils.FintechUtils

@Composable
fun BalanceCard(
  totalBalance: Double,
  savingsBalance: Double,
  isBalanceVisible: Boolean,
  onToggleVisibility: () -> Unit,
  onSendMoney: () -> Unit,
  onAddMoney: () -> Unit,
  onOpenSavingsVault: () -> Unit,
  modifier: Modifier = Modifier
) {
  val cardGradient = Brush.linearGradient(
    colors = listOf(
      Color(0xFF0D47A1),
      Color(0xFF1565C0),
      Color(0xFF0B192C)
    )
  )

  Card(
    shape = RoundedCornerShape(24.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("home_balance_card"),
    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
  ) {
    Box(
      modifier = Modifier
        .background(cardGradient)
        .padding(20.dp)
    ) {
      Column {
        // Top Header inside card
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .background(FintechSecondary, CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Smart Savings Account",
              color = Color.White.copy(alpha = 0.85f),
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium
            )
          }

          IconButton(
            onClick = onToggleVisibility,
            modifier = Modifier
              .size(36.dp)
              .testTag("toggle_balance_visibility")
          ) {
            Icon(
              imageVector = if (isBalanceVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
              contentDescription = "Toggle Balance Visibility",
              tint = Color.White.copy(alpha = 0.9f),
              modifier = Modifier.size(20.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Balance Display
        Text(
          text = if (isBalanceVisible) FintechUtils.formatCurrency(totalBalance) else "₹ ••••••••",
          color = Color.White,
          fontSize = 32.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Savings Vault Sub-card Pill
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = Color.White.copy(alpha = 0.12f),
          modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenSavingsVault)
            .testTag("savings_vault_pill")
        ) {
          Row(
            modifier = Modifier
              .padding(horizontal = 14.dp, vertical = 10.dp)
              .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(32.dp)
                  .background(FintechSecondary.copy(alpha = 0.25f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Savings,
                  contentDescription = null,
                  tint = Color(0xFF6EE7B7),
                  modifier = Modifier.size(18.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "Savings Vault (7.2% APY)",
                  color = Color.White.copy(alpha = 0.9f),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Medium
                )
                Text(
                  text = if (isBalanceVisible) FintechUtils.formatCurrency(savingsBalance) else "₹ ••••••",
                  color = Color(0xFF6EE7B7),
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Deposit",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
              )
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(14.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Card Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          // Send Money Button
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.White,
            modifier = Modifier
              .weight(1f)
              .height(44.dp)
              .clickable(onClick = onSendMoney)
              .testTag("home_card_send_money_button")
          ) {
            Row(
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Send,
                contentDescription = null,
                tint = Color(0xFF0D47A1),
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Send Money",
                color = Color(0xFF0D47A1),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }
          }

          // Add Money Button
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.White.copy(alpha = 0.2f),
            modifier = Modifier
              .weight(1f)
              .height(44.dp)
              .clickable(onClick = onAddMoney)
              .testTag("home_card_add_money_button")
          ) {
            Row(
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Add Money",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun QuickActionGrid(
  onSendMoney: () -> Unit,
  onScanPay: () -> Unit,
  onAddMoney: () -> Unit,
  onTransactions: () -> Unit,
  onCards: () -> Unit,
  onBankTransfer: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      QuickActionButton(
        title = "Send",
        icon = Icons.Default.Send,
        containerColor = Color(0xFFEFF6FF),
        iconColor = FintechPrimary,
        onClick = onSendMoney,
        tag = "quick_action_send"
      )
      QuickActionButton(
        title = "Scan & Pay",
        icon = Icons.Default.QrCodeScanner,
        containerColor = Color(0xFFECFDF5),
        iconColor = FintechSecondary,
        onClick = onScanPay,
        tag = "quick_action_scan"
      )
      QuickActionButton(
        title = "Add Cash",
        icon = Icons.Default.Add,
        containerColor = Color(0xFFFEF3C7),
        iconColor = Color(0xFFD97706),
        onClick = onAddMoney,
        tag = "quick_action_add"
      )
      QuickActionButton(
        title = "History",
        icon = Icons.Default.ReceiptLong,
        containerColor = Color(0xFFF3E8FF),
        iconColor = Color(0xFF9333EA),
        onClick = onTransactions,
        tag = "quick_action_history"
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      QuickActionButton(
        title = "Cards",
        icon = Icons.Default.CreditCard,
        containerColor = Color(0xFFF1F5F9),
        iconColor = Color(0xFF475569),
        onClick = onCards,
        tag = "quick_action_cards"
      )
      QuickActionButton(
        title = "Bank A/C",
        icon = Icons.Default.AccountBalance,
        containerColor = Color(0xFFFFF1F2),
        iconColor = Color(0xFFE11D48),
        onClick = onBankTransfer,
        tag = "quick_action_bank"
      )
      QuickActionButton(
        title = "Vault",
        icon = Icons.Default.Savings,
        containerColor = Color(0xFFE0F2FE),
        iconColor = Color(0xFF0284C7),
        onClick = onSendMoney,
        tag = "quick_action_vault"
      )
      QuickActionButton(
        title = "Bill Pay",
        icon = Icons.Default.ReceiptLong,
        containerColor = Color(0xFFF0FDF4),
        iconColor = Color(0xFF16A34A),
        onClick = onSendMoney,
        tag = "quick_action_bills"
      )
    }
  }
}

@Composable
fun QuickActionButton(
  title: String,
  icon: ImageVector,
  containerColor: Color,
  iconColor: Color,
  onClick: () -> Unit,
  tag: String
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .testTag(tag)
      .padding(4.dp)
  ) {
    Box(
      modifier = Modifier
        .size(56.dp)
        .background(containerColor, RoundedCornerShape(18.dp))
        .border(1.dp, iconColor.copy(alpha = 0.15f), RoundedCornerShape(18.dp)),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = iconColor,
        modifier = Modifier.size(24.dp)
      )
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = title,
      fontSize = 12.sp,
      fontWeight = FontWeight.Medium,
      color = MaterialTheme.colorScheme.onSurface
    )
  }
}

@Composable
fun TransactionItemCard(
  transaction: Transaction,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isCredit = transaction.type == TransactionType.CREDIT
  val isRoundUp = transaction.type == TransactionType.SAVINGS_ROUNDUP

  val iconColor = when {
    isRoundUp -> FintechSecondary
    isCredit -> FintechSecondary
    else -> FintechNavy
  }

  val containerColor = when {
    isRoundUp -> Color(0xFFECFDF5)
    isCredit -> Color(0xFFECFDF5)
    else -> Color(0xFFF1F5F9)
  }

  val categoryIcon = when (transaction.category) {
    TransactionCategory.SHOPPING -> Icons.Default.CreditCard
    TransactionCategory.FOOD_DINING -> Icons.Default.ReceiptLong
    TransactionCategory.TRANSFER -> Icons.Default.Send
    TransactionCategory.SALARY -> Icons.Default.AccountBalance
    TransactionCategory.BILLS_UTILITIES -> Icons.Default.ReceiptLong
    TransactionCategory.SAVINGS -> Icons.Default.Savings
    else -> Icons.Default.ReceiptLong
  }

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 1.dp,
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("txn_item_${transaction.id}")
  ) {
    Row(
      modifier = Modifier
        .padding(14.dp)
        .fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .background(containerColor, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = categoryIcon,
          contentDescription = null,
          tint = iconColor,
          modifier = Modifier.size(22.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = transaction.title,
          fontWeight = FontWeight.SemiBold,
          fontSize = 14.sp,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = FintechUtils.formatShortDate(transaction.timestamp) + " • " + transaction.subtitle,
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Column(horizontalAlignment = Alignment.End) {
        val amountPrefix = if (isCredit || isRoundUp) "+" else "-"
        val amountColor = if (isCredit || isRoundUp) FintechSecondary else MaterialTheme.colorScheme.onSurface

        Text(
          text = "$amountPrefix${FintechUtils.formatCurrency(transaction.amount)}",
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = amountColor
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = if (isRoundUp) "Auto-Save" else "Completed",
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium,
          color = if (isRoundUp) FintechSecondary else Color(0xFF10B981)
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionDetailSheet(
  transaction: Transaction?,
  onDismiss: () -> Unit,
  onRepeatPayment: (Transaction) -> Unit
) {
  if (transaction == null) return

  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val clipboardManager = LocalClipboardManager.current
  var copiedText by remember { mutableStateOf<String?>(null) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface
  ) {
    Column(
      modifier = Modifier
        .padding(horizontal = 24.dp)
        .padding(bottom = 32.dp)
        .fillMaxWidth()
    ) {
      // Header with checkmark
      Box(
        modifier = Modifier
          .size(64.dp)
          .background(Color(0xFFECFDF5), CircleShape)
          .align(Alignment.CenterHorizontally),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.CheckCircle,
          contentDescription = null,
          tint = FintechSecondary,
          modifier = Modifier.size(36.dp)
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "Payment Successful",
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        color = FintechSecondary,
        modifier = Modifier.align(Alignment.CenterHorizontally)
      )

      Text(
        text = FintechUtils.formatCurrency(transaction.amount),
        fontSize = 32.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.align(Alignment.CenterHorizontally)
      )

      Spacer(modifier = Modifier.height(20.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
      Spacer(modifier = Modifier.height(16.dp))

      DetailRow(label = "Recipient / Source", value = transaction.recipientOrSender)
      if (transaction.upiId.isNotBlank()) {
        DetailRow(label = "UPI ID", value = transaction.upiId)
      }
      DetailRow(
        label = "Transaction ID",
        value = transaction.id,
        isCopyable = true,
        onCopy = {
          clipboardManager.setText(AnnotatedString(transaction.id))
          copiedText = "Transaction ID copied"
        }
      )
      if (transaction.referenceId.isNotBlank()) {
        DetailRow(
          label = "UPI Ref No",
          value = transaction.referenceId,
          isCopyable = true,
          onCopy = {
            clipboardManager.setText(AnnotatedString(transaction.referenceId))
            copiedText = "Reference No copied"
          }
        )
      }
      DetailRow(label = "Date & Time", value = FintechUtils.formatDate(transaction.timestamp))
      DetailRow(label = "Payment Mode", value = "Smart Saving Pay Wallet")
      if (transaction.note.isNotBlank()) {
        DetailRow(label = "Note", value = transaction.note)
      }

      if (copiedText != null) {
        Text(
          text = copiedText!!,
          color = FintechSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 4.dp)
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedButton(
          onClick = {
            clipboardManager.setText(
              AnnotatedString("Receipt for ${transaction.title}: ${FintechUtils.formatCurrency(transaction.amount)} via Smart Saving Pay. Txn ID: ${transaction.id}")
            )
            copiedText = "Receipt summary copied!"
          },
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Share")
        }

        Surface(
          shape = RoundedCornerShape(100.dp),
          color = FintechPrimary,
          modifier = Modifier
            .weight(1.3f)
            .height(44.dp)
            .clickable {
              onDismiss()
              onRepeatPayment(transaction)
            }
        ) {
          Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Pay Again", color = Color.White, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun DetailRow(
  label: String,
  value: String,
  isCopyable: Boolean = false,
  onCopy: (() -> Unit)? = null
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      fontSize = 13.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = value,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurface
      )
      if (isCopyable && onCopy != null) {
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Copy",
          fontSize = 11.sp,
          color = FintechPrimary,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.clickable(onClick = onCopy)
        )
      }
    }
  }
}

@Composable
fun VirtualDebitCardView(
  card: VirtualCard,
  showDetails: Boolean,
  onToggleDetails: () -> Unit,
  modifier: Modifier = Modifier
) {
  val cardGradient = if (card.isFrozen) {
    Brush.linearGradient(listOf(Color(0xFF475569), Color(0xFF1E293B)))
  } else {
    Brush.linearGradient(
      listOf(
        Color(0xFF0F2027),
        Color(0xFF203A43),
        Color(0xFF2C5364)
      )
    )
  }

  Card(
    shape = RoundedCornerShape(22.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
    modifier = modifier
      .fillMaxWidth()
      .height(210.dp)
      .testTag("virtual_card_${card.id}")
  ) {
    Box(
      modifier = Modifier
        .background(cardGradient)
        .padding(20.dp)
    ) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // Card Top Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .background(Color(0xFFFFD700).copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFFFFD700).copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
              contentAlignment = Alignment.Center
            ) {
              Text("💳", fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = card.cardType,
              color = Color.White.copy(alpha = 0.9f),
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp
            )
          }

          if (card.isFrozen) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = FintechRose.copy(alpha = 0.8f)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("FROZEN", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
          } else {
            Text(
              text = "Smart Saving Pay",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              letterSpacing = 1.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Card Number
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (showDetails) card.fullCardNumber else card.cardNumberMasked,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            fontFamily = FontFamily.Monospace
          )

          IconButton(
            onClick = onToggleDetails,
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = if (showDetails) Icons.Default.Visibility else Icons.Default.VisibilityOff,
              contentDescription = "Toggle card details",
              tint = Color.White.copy(alpha = 0.8f),
              modifier = Modifier.size(18.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Card Bottom Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          Column {
            Text(
              text = "CARDHOLDER",
              fontSize = 9.sp,
              color = Color.White.copy(alpha = 0.6f),
              fontWeight = FontWeight.Medium
            )
            Text(
              text = card.cardHolder,
              color = Color.White,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          }

          Column {
            Text(
              text = "EXPIRES",
              fontSize = 9.sp,
              color = Color.White.copy(alpha = 0.6f),
              fontWeight = FontWeight.Medium
            )
            Text(
              text = card.expiryDate,
              color = Color.White,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = "CVV",
              fontSize = 9.sp,
              color = Color.White.copy(alpha = 0.6f),
              fontWeight = FontWeight.Medium
            )
            Text(
              text = if (showDetails) card.cvv else "•••",
              color = Color.White,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          }
        }
      }
    }
  }
}
