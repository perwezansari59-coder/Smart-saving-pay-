package com.example.data

import com.example.model.BankAccount
import com.example.model.RecentPayee
import com.example.model.SavingsGoal
import com.example.model.Transaction
import com.example.model.TransactionCategory
import com.example.model.TransactionStatus
import com.example.model.TransactionType
import com.example.model.UserProfile
import com.example.model.VirtualCard

object MockData {
  val defaultUser = UserProfile(
    name = "Alex Morgan",
    phone = "+91 98765 43210",
    email = "alex.morgan@email.com",
    upiId = "alex@smartsavingpay",
    isKycVerified = true
  )

  val recentPayees = listOf(
    RecentPayee("Rahul Sharma", "rahul@oksbi", "+91 98231 11223", "RS", 0xFF10B981),
    RecentPayee("Priya Patel", "priya@okaxis", "+91 97112 33445", "PP", 0xFF6366F1),
    RecentPayee("David Chen", "david@okhdfc", "+91 96554 44556", "DC", 0xFFF59E0B),
    RecentPayee("Sneha Roy", "sneha@paytm", "+91 95443 66778", "SR", 0xFFEC4899),
    RecentPayee("Rohan Verma", "rohan@smartpay", "+91 94332 88990", "RV", 0xFF3B82F6)
  )

  val initialCards = listOf(
    VirtualCard(
      id = "card_1",
      cardNumberMasked = "4242 •••• •••• 8842",
      fullCardNumber = "4242 9182 3746 8842",
      cardHolder = "ALEX MORGAN",
      expiryDate = "08/29",
      cvv = "582",
      cardType = "Smart RuPay Platinum",
      isFrozen = false,
      onlineEnabled = true,
      internationalEnabled = false,
      dailyLimit = 50000.0
    ),
    VirtualCard(
      id = "card_2",
      cardNumberMasked = "5399 •••• •••• 1920",
      fullCardNumber = "5399 7120 4821 1920",
      cardHolder = "ALEX MORGAN",
      expiryDate = "11/30",
      cvv = "914",
      cardType = "Smart Visa Signature",
      isFrozen = true,
      onlineEnabled = true,
      internationalEnabled = true,
      dailyLimit = 100000.0
    )
  )

  val initialBankAccounts = listOf(
    BankAccount(
      id = "bank_1",
      bankName = "Smart Savings Bank",
      accountNumberMasked = "•••• •••• 8219",
      ifsc = "SMPB0001092",
      isPrimary = true,
      balance = 48750.0
    ),
    BankAccount(
      id = "bank_2",
      bankName = "HDFC Bank",
      accountNumberMasked = "•••• •••• 4012",
      ifsc = "HDFC0000240",
      isPrimary = false,
      balance = 125000.0
    )
  )

  val initialSavingsGoals = listOf(
    SavingsGoal(
      id = "goal_1",
      title = "Emergency Fund",
      targetAmount = 50000.0,
      currentAmount = 38500.0,
      iconEmoji = "🛡️"
    ),
    SavingsGoal(
      id = "goal_2",
      title = "Goa Vacation Trip",
      targetAmount = 25000.0,
      currentAmount = 16200.0,
      iconEmoji = "🌴"
    ),
    SavingsGoal(
      id = "goal_3",
      title = "MacBook Pro M-Series",
      targetAmount = 140000.0,
      currentAmount = 74500.0,
      iconEmoji = "💻"
    )
  )

  fun getInitialTransactions(): List<Transaction> {
    val now = System.currentTimeMillis()
    val hour = 3600 * 1000L
    val day = 24 * hour

    return listOf(
      Transaction(
        id = "TXN94817203",
        title = "Grocery Supermart",
        subtitle = "UPI payment to Reliance Fresh",
        amount = 1420.0,
        type = TransactionType.DEBIT,
        category = TransactionCategory.SHOPPING,
        timestamp = now - (2 * hour),
        recipientOrSender = "Reliance Fresh",
        upiId = "reliancefresh@icici",
        status = TransactionStatus.SUCCESS,
        referenceId = "UPI/428192837192",
        note = "Monthly groceries"
      ),
      Transaction(
        id = "TXN94815911",
        title = "Round-Up Auto Save",
        subtitle = "Rounded up ₹80 from Grocery",
        amount = 80.0,
        type = TransactionType.SAVINGS_ROUNDUP,
        category = TransactionCategory.SAVINGS,
        timestamp = now - (2 * hour),
        recipientOrSender = "Smart Savings Vault",
        upiId = "savings@smartsavingpay",
        status = TransactionStatus.SUCCESS,
        referenceId = "SAV/819204810294",
        note = "Auto Round-up 5% boost"
      ),
      Transaction(
        id = "TXN94781290",
        title = "Salary Credit",
        subtitle = "Direct deposit from TechCorp Labs",
        amount = 75000.0,
        type = TransactionType.CREDIT,
        category = TransactionCategory.SALARY,
        timestamp = now - (1 * day),
        recipientOrSender = "TechCorp Labs Private Ltd",
        upiId = "techcorp@hdfcbank",
        status = TransactionStatus.SUCCESS,
        referenceId = "NEFT/TECH829104",
        note = "September Salary"
      ),
      Transaction(
        id = "TXN94651928",
        title = "Electricity Bill",
        subtitle = "Tata Power Mumbai Utility",
        amount = 2150.0,
        type = TransactionType.DEBIT,
        category = TransactionCategory.BILLS_UTILITIES,
        timestamp = now - (2 * day),
        recipientOrSender = "Tata Power",
        upiId = "tatapower@billpay",
        status = TransactionStatus.SUCCESS,
        referenceId = "BBPS/9182371920",
        note = "Consumer #984210"
      ),
      Transaction(
        id = "TXN94551029",
        title = "Dinner at Olive Bistro",
        subtitle = "Paid via QR scan",
        amount = 1860.0,
        type = TransactionType.DEBIT,
        category = TransactionCategory.FOOD_DINING,
        timestamp = now - (3 * day),
        recipientOrSender = "Olive Bistro",
        upiId = "olivebistro@paytm",
        status = TransactionStatus.SUCCESS,
        referenceId = "UPI/3920194810",
        note = "Weekend team dinner"
      ),
      Transaction(
        id = "TXN94401827",
        title = "Received from Priya Patel",
        subtitle = "Split bill repayment",
        amount = 930.0,
        type = TransactionType.CREDIT,
        category = TransactionCategory.TRANSFER,
        timestamp = now - (3 * day + 2 * hour),
        recipientOrSender = "Priya Patel",
        upiId = "priya@okaxis",
        status = TransactionStatus.SUCCESS,
        referenceId = "UPI/9182048192",
        note = "Olive bistro split"
      ),
      Transaction(
        id = "TXN94301982",
        title = "Savings Vault Interest",
        subtitle = "Monthly 7.2% APY Interest Credit",
        amount = 110.40,
        type = TransactionType.CREDIT,
        category = TransactionCategory.SAVINGS,
        timestamp = now - (5 * day),
        recipientOrSender = "Smart Saving Pay Vault",
        upiId = "interest@smartsavingpay",
        status = TransactionStatus.SUCCESS,
        referenceId = "INT/481920491",
        note = "Savings interest payout"
      ),
      Transaction(
        id = "TXN94101928",
        title = "Metro Smart Card Recharge",
        subtitle = "Quick NFC Pay",
        amount = 500.0,
        type = TransactionType.DEBIT,
        category = TransactionCategory.BILLS_UTILITIES,
        timestamp = now - (6 * day),
        recipientOrSender = "Metro Rail Corp",
        upiId = "metrorail@sbi",
        status = TransactionStatus.SUCCESS,
        referenceId = "UPI/1092847192",
        note = "Commuter pass top-up"
      )
    )
  }
}
