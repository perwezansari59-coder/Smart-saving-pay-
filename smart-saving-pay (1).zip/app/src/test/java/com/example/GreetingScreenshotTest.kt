package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.components.BalanceCard
import com.example.ui.theme.SmartSavingPayTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun app_balance_card_screenshot() {
    composeTestRule.setContent {
      SmartSavingPayTheme {
        BalanceCard(
          totalBalance = 48750.0,
          savingsBalance = 18400.0,
          isBalanceVisible = true,
          onToggleVisibility = {},
          onSendMoney = {},
          onAddMoney = {},
          onOpenSavingsVault = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/balance_card.png")
  }
}
